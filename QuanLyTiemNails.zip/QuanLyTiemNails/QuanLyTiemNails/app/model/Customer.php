<?php
class Customer extends Database
{
    public function all(): mixed
    {
        $sql = parent::$connection->prepare(query: "SELECT * FROM `customers`");
        return parent::select($sql);
    }

    public function allBin()
    {
        $sql = parent::$connection->prepare('SELECT * FROM `products` WHERE `status` = 0');
        return parent::select($sql);
    }


    public function find($customerId)
    {
        // 2. Tạo câu query
        $sql = parent::$connection->prepare("SELECT * from `customers` WHERE `id`=?");
        $sql->bind_param('i', $customerId);
        // 3 & 4
        return parent::select($sql)[0];
    }

    public function findByCategory($id, $limit = '')
    {
        $limit = ($limit != '') ? "LIMIT $limit" : '';
        // 2. Tạo câu query
        $sql = parent::$connection->prepare("SELECT *
                                            FROM `category_product`
                                            INNER JOIN `products`
                                            ON `category_product`.`product_id` = `products`.`id`
                                            WHERE `category_id`=?
                                            $limit");
        $sql->bind_param('i', $id);
        // 3 & 4
        return parent::select($sql);
    }
    public function getCategories($serviceId)
    {
        $sql = parent::$connection->prepare("
            SELECT `category_id` 
            FROM `category_service`
            WHERE `service_id` = ?
        ");
        $sql->bind_param('i', $serviceId);
        $sql->execute();
        $result = $sql->get_result();
        $categories = [];
        while ($row = $result->fetch_assoc()) {
            $categories[] = $row['category_id'];
        }
        return $categories;
    }

    public function findByKeyWord($keyword)
    {
        // 2. Tạo câu query
        $sql = parent::$connection->prepare("SELECT * FROM `products` WHERE `name` LIKE ?");
        $keyword = "%{$keyword}%";
        $sql->bind_param('s', $keyword);
        // 3 & 4
        return parent::select($sql);
    }
    //thêm sản phẩm
    public function add($customer_name, $phone, $email, $address): bool
    {
        try {
            $sql = parent::$connection->prepare("INSERT INTO `customers` (`customer_name`, `phone`, `email`, `address`) VALUES (?, ?, ?, ?)");
            $sql->bind_param('ssss', $customer_name, $phone, $email, $address);

            return $sql->execute();
        } catch (mysqli_sql_exception $e) {
            if ($e->getCode() === 1062) {
                error_log("Duplicate phone customer: " . $phone);
                return false;
            }

            throw $e;
        }
    }
    //Xóa sản phẩm 
    public function delete($serviceId)
    {
        $sql = parent::$connection->prepare("DELETE FROM `customers` WHERE `id`=?");
        $sql->bind_param('i', $serviceId);

        return $sql->execute();
    }

    public function deleteBin($productId)
    {
        // 2. Tạo câu query
        $sql = parent::$connection->prepare("UPDATE `services` SET `status`= 0 WHERE `id`=?");
        $sql->bind_param('i', $productId);
        // 3 & 4
        return $sql->execute();
    }

    public function restore($productIds)
    {
        // 2. Tạo câu query
        // Tạo chuỗi kiểu ?,?,?
        $insertPlace = str_repeat("?,", count($productIds) - 1) . "?";
        // Tạo chuỗi iiiiiiii
        $insertType = str_repeat('i', count($productIds));

        $sql = parent::$connection->prepare("UPDATE `products` SET `status`=1 WHERE `id` IN ($insertPlace)");
        $sql->bind_param($insertType, ...$productIds);
        // 3 & 4
        return $sql->execute();
    }
    //update sản phẩm
    // public function update($service_id, $service_name, $price, $duration, $category_ids)
    // {
    //     $sql = parent::$connection->prepare("
    //      UPDATE `services`
    //      SET `service_name` = ?, `price` = ?, `service_duration` = ?
    //      WHERE `id` = ?
    //  ");
    //     $sql->bind_param('sdii', $service_name, $price, $duration, $service_id);
    //     $sql->execute();

    //     if (!$sql->execute()) {
    //         return false; // Return false if the update query fails
    //     }

    //     $sql = parent::$connection->prepare("
    //      DELETE FROM `category_service`
    //      WHERE `service_id` = ?
    //  ");
    //     $sql->bind_param('i', $service_id);
    //     $sql->execute();

    //     foreach ($category_ids as $categoryId) {
    //         $sql = parent::$connection->prepare("
    //          INSERT INTO `category_service` (`category_id`, `service_id`)
    //          VALUES (?, ?)
    //      ");
    //         $sql->bind_param('ii', $categoryId, $service_id);
    //         $sql->execute();
    //     }

    //     return true;
    // }
    public function update($customer_id, $customer_name, $email, $phone, $address)
    {
        // Update service details
        $sql = parent::$connection->prepare("
        UPDATE `customers`
        SET `customer_name` = ?, `email` = ?, `phone` = ?, `address` = ?
        WHERE `id` = ?
    ");
        $sql->bind_param('sssss', $customer_name, $email, $phone, $address, $customer_id);

        if (!$sql->execute()) {
            return false; // Return false if the service update query fails
        }

        return true; // Return true if all queries succeed
    }
    
    
    
    public function countCustomers() {
        $sql = parent::$connection->prepare("SELECT COUNT(*) FROM `customers`");
        $sql->execute();
        $result = $sql->get_result();
        $row = $result->fetch_row();
        return $row[0]; // Trả về số lượng khách hàng
    }
    public function getCustomers($limit, $start) {
        $sql = parent::$connection->prepare("SELECT * FROM `customers` LIMIT ?, ?");
        $sql->bind_param('ii', $start, $limit); // Bind start và limit
        $sql->execute();
        $result = $sql->get_result();
        $customers = [];
        
        while ($row = $result->fetch_assoc()) {
            $customers[] = $row;
        }
        
        return $customers;
    }
    public function countCustomersByName($name) {
        $sql = parent::$connection->prepare("SELECT COUNT(*) FROM `customers` WHERE `customer_name` LIKE ?");
        $name = '%' . $name . '%'; // Tạo wildcard cho câu lệnh LIKE
        $sql->bind_param('s', $name); // Bind tên khách hàng
        $sql->execute();
        $result = $sql->get_result();
        $row = $result->fetch_row();
        return $row[0]; // Trả về tổng số khách hàng phù hợp
    }
    
    public function searchCustomersByName($name, $limit, $start) {
        $sql = parent::$connection->prepare("SELECT * FROM `customers` WHERE `customer_name` LIKE ? LIMIT ?, ?");
        $name = '%' . $name . '%'; // Tạo wildcard cho câu lệnh LIKE
        $sql->bind_param('sii', $name, $start, $limit); // Bind tên khách hàng, start, và limit
        $sql->execute();
        $result = $sql->get_result();
        $customers = [];
        
        while ($row = $result->fetch_assoc()) {
            $customers[] = $row;
        }
        
        return $customers;
    }
    
    
    
}
