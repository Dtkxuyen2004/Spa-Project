<?php
class Payment extends Database
{
    public function create($data)
    {
        $sql = parent::$connection->prepare("
            INSERT INTO payments (customer_id, customer_name, staff_ids, staff_names, service_ids, service_names, total, method_payment)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $sql->bind_param(
            "isssssds",
            $data['customer_id'],
            $data['customer_name'],
            $data['staff_ids'],
            $data['staff_names'],
            $data['service_ids'],
            $data['service_names'],
            $data['total'],
            $data['method_payment']
        );
        $sql->execute();
        return $sql->insert_id;
    }

    // Lấy tất cả thanh toán
    public function getAllPayments()
    {
        $sql = parent::$connection->prepare("SELECT * FROM payments ORDER BY created_at DESC");
        $sql->execute();
        return $sql->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    // Tìm kiếm thanh toán
    public function searchPayments($keyword)
    {
        $likeKeyword = '%' . $keyword . '%';
        $sql = parent::$connection->prepare("
            SELECT * FROM payments 
            WHERE customer_name LIKE ? 
            OR staff_names LIKE ? 
            OR service_names LIKE ? 
            OR method_payment LIKE ? 
            ORDER BY created_at DESC
        ");
        $sql->bind_param("ssss", $likeKeyword, $likeKeyword, $likeKeyword, $likeKeyword);
        $sql->execute();
        return $sql->get_result()->fetch_all(MYSQLI_ASSOC);
    }
}
