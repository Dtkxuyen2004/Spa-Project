<?php
class Category extends Database
{
    public function all()
    {
        // 2. Tạo sql
        $sql = parent::$connection->prepare('SELECT * FROM `categories`');
        return parent::select($sql);
    }
    
    public function addCategory($categoryName, $description) {
        $sql = parent::$connection->prepare("
            INSERT INTO `categories` (`category_name`, `description`)
            VALUES (?, ?)
        ");
        $sql->bind_param('ss', $categoryName, $description);
        return $sql->execute();
    }
    
    

}
