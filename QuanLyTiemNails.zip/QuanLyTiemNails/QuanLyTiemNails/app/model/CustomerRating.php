<?php
class CustomerRating extends Database
{
    // Thêm đánh giá dịch vụ với tên khách hàng và thời gian
    public function addRating($customerId, $serviceRating, $comments) {
        // Lấy tên khách hàng từ bảng `customers` dựa vào `customerId`
        $customerModel = new Customer();
        $customer = $customerModel->find($customerId); // Giả sử phương thức `find` trả về một mảng thông tin của khách hàng

        // Kiểm tra xem khách hàng có tồn tại hay không
        if (!$customer) {
            return false; // Nếu không tìm thấy khách hàng, trả về false
        }

        // Chèn đánh giá vào bảng `customer_ratings`
        $sql = parent::$connection->prepare("INSERT INTO `customer_ratings` (`customer_name`, `service_rating`, `comments`, `created_at`) 
                                             VALUES (?, ?, ?, CURRENT_TIMESTAMP)");
        $sql->bind_param('sis', $customer['customer_name'], $serviceRating, $comments);

        return $sql->execute(); // Thực thi câu lệnh SQL
    }

    // Lấy tất cả các đánh giá từ cơ sở dữ liệu
    public function getAllRatings() {
        $sql = parent::$connection->prepare("SELECT * FROM `customer_ratings` ORDER BY `created_at` DESC");
        $sql->execute();
        $result = $sql->get_result();
        $ratings = [];
        
        // Lấy tất cả các dòng dữ liệu và thêm vào mảng
        while ($row = $result->fetch_assoc()) {
            $ratings[] = $row;
        }

        return $ratings; // Trả về danh sách đánh giá
    }

    // Lấy đánh giá theo ID khách hàng
    public function getRatingsByCustomer($customerId) {
        $sql = parent::$connection->prepare("SELECT * FROM `customer_ratings` WHERE `customer_id` = ? ORDER BY `created_at` DESC");
        $sql->bind_param('i', $customerId);
        $sql->execute();
        $result = $sql->get_result();
        $ratings = [];

        // Kiểm tra xem có dữ liệu không
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $ratings[] = $row;
            }
        }

        return $ratings; // Trả về danh sách đánh giá của khách hàng
    }
}
?>