<?php
class User extends Database
{
    /**
     * Đăng ký người dùng mới
     * @param string $username
     * @param string $email
     * @param string $password
     * @return bool
     */
    public function register($username, $email, $password) {
        // Tạo câu truy vấn
        $sql = parent::$connection->prepare('INSERT INTO `users`(`username`, `email`, `password`) VALUES (?, ?, ?)');
        
        // Mã hóa mật khẩu
        $password = password_hash($password, PASSWORD_DEFAULT);

        // Liên kết tham số
        $sql->bind_param('sss', $username, $email, $password);
        
        // Thực thi truy vấn
        return $sql->execute();
    }

    /**
     * Đăng nhập người dùng
     * @param string $username
     * @param string $password
     * @return array|false
     */
    public function getUserlogin($username, $password) {
        // Tạo câu truy vấn
        $sql = parent::$connection->prepare('SELECT * FROM `users` WHERE `username` = ?');

        // Liên kết tham số
        $sql->bind_param('s', $username);
        $sql->execute();
        // Thực thi truy vấn và lấy kết quả
        $result = $sql->get_result();
        $customers = [];
        
        while ($row = $result->fetch_assoc()) {
            $customers[] = $row;
        }
        
        return $customers;
    }
    public function findLogin($username, $password) {
        $sql = parent::$connection->prepare('SELECT * FROM `users` WHERE `username` = ?');
        $sql->bind_param('s', $username);
        $user = parent::select($sql);
    
        if (!empty($user) && password_verify($password, $user[0]['password'])) {
            return true;
        }
        return false;
    }
    public function findByEmail($email) {
        // Tạo câu truy vấn
        $sql = parent::$connection->prepare('SELECT * FROM `users` WHERE `email` = ?');
        $sql->bind_param('s', $email);

        // Thực thi truy vấn và lấy kết quả
        $user = parent::select($sql);

        // Kiểm tra nếu có kết quả
        return !empty($user);
    }
    public function updatePassword($email, $newPassword)
    {
        $sql = parent::$connection->prepare('UPDATE `users` SET `password` = ? WHERE `email` = ?');
        $sql->bind_param('ss', $newPassword, $email);
        return $sql->execute();
    }
    public function updateUserInfo($userId, $userEmail, $userPhone)
    {
        $sql = parent::$connection->prepare('UPDATE `users` SET `email` = ?, `phone` = ? WHERE `id` = ?');
        $sql->bind_param('ssi', $userEmail, $userPhone, $userId);
        return $sql->execute();
    }
}
