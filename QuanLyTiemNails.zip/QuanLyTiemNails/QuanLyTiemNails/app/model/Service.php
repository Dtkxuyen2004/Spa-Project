<?php
class Service extends Database
{
    public function all(): mixed
    {
        // 2. Tạo câu query
        // $sql = parent::$connection->prepare('SELECT * from `products`');
        $sql = parent::$connection->prepare(query: "SELECT `categories`.*, CONCAT(`services`.price, ' $') AS price, `services`.service_name, `services`.id AS service_id 
                                            FROM `categories`
                                            LEFT JOIN `category_service`
                                            ON `categories`.`id` = `category_service`.`category_id`
                                            LEFT JOIN `services`
                                            ON `services`.`id` = `category_service`.`service_id`
                                            GROUP BY `services`.id");
        // 3 & 4
        return parent::select($sql);
    }

    public function allBin()
    {
        $sql = parent::$connection->prepare('SELECT * FROM `products` WHERE `status` = 0');
        return parent::select($sql);
    }


    public function find($id)
    {
        // 2. Tạo câu query
        $sql = parent::$connection->prepare("SELECT * from `services` WHERE `id`=?");
        $sql->bind_param('i', $id);
        // 3 & 4
        return parent::select($sql)[0];
    }

    public function findById($id)
    {
        $sql = parent::$connection->prepare("SELECT * FROM services WHERE id = ?");
        $sql->bind_param("i", $id);
        $sql->execute();
        return $sql->get_result()->fetch_assoc();
    }

    public function findByCategory($id, $limit = '')
    {
        $limit = ($limit != '') ? "LIMIT $limit" : '';
        // 2. Tạo câu query
        $sql = parent::$connection->prepare("SELECT *
                                            FROM `category_product`
                                            INNER JOIN `products`
                                            ON `category_product`.`product_id` = `products`.`id`
                                            WHERE `category_id`=?
                                            $limit");
        $sql->bind_param('i', $id);
        // 3 & 4
        return parent::select($sql);
    }
    public function getCategories($serviceId)
    {
        $sql = parent::$connection->prepare("
            SELECT `category_id` 
            FROM `category_service`
            WHERE `service_id` = ?
        ");
        $sql->bind_param('i', $serviceId);
        $sql->execute();
        $result = $sql->get_result();
        $categories = [];
        while ($row = $result->fetch_assoc()) {
            $categories[] = $row['category_id'];
        }
        return $categories;
    }

    public function findByKeyWord($keyword)
    {
        // 2. Tạo câu query
        $sql = parent::$connection->prepare("SELECT * FROM `products` WHERE `name` LIKE ?");
        $keyword = "%{$keyword}%";
        $sql->bind_param('s', $keyword);
        // 3 & 4
        return parent::select($sql);
    }
    //thêm sản phẩm
    public function add($name, $price, $duration, $category_ids): mixed
    {
        // 2. Tạo câu query
        $sql = parent::$connection->prepare("INSERT INTO `services` (`service_name`, `price`, `service_duration`) VALUES (?, ?, ?)");
        $sql->bind_param('sdi', $name, $price, $duration);
        // 3 & 4
        $sql->execute();


        $serviceId = parent::$connection->insert_id;
        // $insertPlace = str_repeat("(?, $serviceId), ", count($category_ids) - 1) . "(?, $serviceId)";
        // $insertType = str_repeat('i', count($category_ids));

        $sql = parent::$connection->prepare(query: "INSERT INTO `category_service`(`category_id`, `service_id`) VALUES (?, ?)");
        $sql->bind_param('ii', $category_ids, $serviceId);

        return $sql->execute();
    }
    //Xóa sản phẩm 
    public function delete($serviceId)
    {
        $sql = parent::$connection->prepare("DELETE FROM `services` WHERE `id`=?");
        $sql->bind_param('i', $serviceId);

        $deleteCategoriesServices = parent::$connection->prepare("
        DELETE FROM `category_service` WHERE `service_id` = ?
    ");
        $deleteCategoriesServices->bind_param('i', $serviceId);
        if (!$deleteCategoriesServices->execute()) {
            return false; // Return false if the delete query fails
        }
        return $sql->execute();
    }

    public function deleteBin($productId)
    {
        // 2. Tạo câu query
        $sql = parent::$connection->prepare("UPDATE `services` SET `status`= 0 WHERE `id`=?");
        $sql->bind_param('i', $productId);
        // 3 & 4
        return $sql->execute();
    }

    public function restore($productIds)
    {
        // 2. Tạo câu query
        // Tạo chuỗi kiểu ?,?,?
        $insertPlace = str_repeat("?,", count($productIds) - 1) . "?";
        // Tạo chuỗi iiiiiiii
        $insertType = str_repeat('i', count($productIds));

        $sql = parent::$connection->prepare("UPDATE `products` SET `status`=1 WHERE `id` IN ($insertPlace)");
        $sql->bind_param($insertType, ...$productIds);
        // 3 & 4
        return $sql->execute();
    }
    //update sản phẩm
    // public function update($service_id, $service_name, $price, $duration, $category_ids)
    // {
    //     $sql = parent::$connection->prepare("
    //      UPDATE `services`
    //      SET `service_name` = ?, `price` = ?, `service_duration` = ?
    //      WHERE `id` = ?
    //  ");
    //     $sql->bind_param('sdii', $service_name, $price, $duration, $service_id);
    //     $sql->execute();

    //     if (!$sql->execute()) {
    //         return false; // Return false if the update query fails
    //     }

    //     $sql = parent::$connection->prepare("
    //      DELETE FROM `category_service`
    //      WHERE `service_id` = ?
    //  ");
    //     $sql->bind_param('i', $service_id);
    //     $sql->execute();

    //     foreach ($category_ids as $categoryId) {
    //         $sql = parent::$connection->prepare("
    //          INSERT INTO `category_service` (`category_id`, `service_id`)
    //          VALUES (?, ?)
    //      ");
    //         $sql->bind_param('ii', $categoryId, $service_id);
    //         $sql->execute();
    //     }

    //     return true;
    // }
    public function update($service_id, $service_name, $price, $duration, $category_id)
    {
        // Update service details
        $sql = parent::$connection->prepare("
        UPDATE `services`
        SET `service_name` = ?, `price` = ?, `service_duration` = ?
        WHERE `id` = ?
    ");
        $sql->bind_param('sdii', $service_name, $price, $duration, $service_id);

        if (!$sql->execute()) {
            return false; // Return false if the service update query fails
        }

        // Remove existing categories for the service
        $deleteCategories = parent::$connection->prepare("
        DELETE FROM `category_service` WHERE `service_id` = ?
    ");
        $deleteCategories->bind_param('i', $service_id);
        if (!$deleteCategories->execute()) {
            return false; // Return false if the delete query fails
        }

        // Add the new category for the service
        $insertCategory = parent::$connection->prepare("
        INSERT INTO `category_service` (`category_id`, `service_id`) VALUES (?, ?)
    ");
        $insertCategory->bind_param('ii', $category_id, $service_id);
        if (!$insertCategory->execute()) {
            return false; // Return false if the insert query fails
        }

        return true; // Return true if all queries succeed
    }
    public function countService() {
        $sql = parent::$connection->prepare("SELECT COUNT(*) FROM `services`");
        $sql->execute();
        $result = $sql->get_result();
        $row = $result->fetch_row();
        return $row[0]; // Trả về số lượng khách hàng
    }
    public function getServices($limit, $start) {
        $sql = parent::$connection->prepare("
            SELECT `categories`.*, CONCAT(`services`.price, ' $') AS price, `services`.service_name, `services`.id AS service_id 
            FROM `categories`
            LEFT JOIN `category_service`
            ON `categories`.`id` = `category_service`.`category_id`
            LEFT JOIN `services`
            ON `services`.`id` = `category_service`.`service_id`
            GROUP BY `services`.id
            LIMIT ?, ?
        ");
        $sql->bind_param('ii', $start, $limit);
        $sql->execute();
        $result = $sql->get_result();
        $services = [];
        while ($row = $result->fetch_assoc()) {
            $services[] = $row;
        }
        return $services;
    }
    public function countServicesByKeyword($keyword) {
        $sql = parent::$connection->prepare("
            SELECT COUNT(*)
            FROM `services`
            WHERE `service_name` LIKE ?
        ");
        $keyword = "%{$keyword}%";
        $sql->bind_param('s', $keyword);
        $sql->execute();
        $result = $sql->get_result();
        $row = $result->fetch_row();
        return $row[0]; // Trả về số lượng dịch vụ
    }

    // Tìm kiếm dịch vụ theo từ khóa
    public function searchServicesByKeyword($keyword, $limit, $start) {
        $sql = parent::$connection->prepare("
            SELECT `categories`.*, CONCAT(`services`.price, ' $') AS price, `services`.service_name, `services`.id AS service_id 
            FROM `categories`
            LEFT JOIN `category_service`
            ON `categories`.`id` = `category_service`.`category_id`
            LEFT JOIN `services`
            ON `services`.`id` = `category_service`.`service_id`
            WHERE `services`.service_name LIKE ?
            GROUP BY `services`.id
            LIMIT ?, ?
        ");
        $keyword = "%{$keyword}%";
        $sql->bind_param('sii', $keyword, $start, $limit);
        $sql->execute();
        $result = $sql->get_result();
        $services = [];
        while ($row = $result->fetch_assoc()) {
            $services[] = $row;
        }
        return $services;
    }
    

}
