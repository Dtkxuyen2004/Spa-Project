<?php
class Category extends Database
{
    public function all()
    {
        // 2. Tạo sql
        $sql = parent::$connection->prepare('SELECT * FROM `categories`');
        return parent::select($sql);
    }

    public function getProductsFromCategories($id, $limit = '')
    {
        // 2. Tạo sql
        $limit = ($limit != '') ? "LIMIT $limit" : '';
        $sql = parent::$connection->prepare("SELECT *
                                            FROM `category_product`
                                            INNER JOIN `products`
                                            ON category_product.product_id = products.id
                                            WHERE `category_id`=?
                                            $limit");
        $sql->bind_param('i', $id);
        return parent::select($sql);
    }
}
