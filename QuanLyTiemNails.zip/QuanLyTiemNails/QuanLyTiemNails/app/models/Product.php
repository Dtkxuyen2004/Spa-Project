<?php
class Product extends Database
{
    public function all()
    {
        // 2. Tạo câu query
        // $sql = parent::$connection->prepare('SELECT * from `products`');
        $sql = parent::$connection->prepare("SELECT `products`.*, GROUP_CONCAT(`categories`.`name`) AS 'categories_name'
                                            FROM `products`
                                            LEFT JOIN `category_product`
                                            ON `products`.`id` = `category_product`.`product_id`
                                            LEFT JOIN `categories`
                                            ON `categories`.`id` = `category_product`.`category_id`
                                            GROUP BY `products`.id");
        // 3 & 4
        return parent::select($sql);
    }

    public function allBin()
{
    $sql = parent::$connection->prepare('SELECT * FROM `products` WHERE `status` = 0');
    return parent::select($sql);
}


    public function find($id)
    {
        // 2. Tạo câu query
        $sql = parent::$connection->prepare("SELECT * from `products` WHERE `id`=?");
        $sql->bind_param('i', $id);
        // 3 & 4
        return parent::select($sql)[0];
    }

    public function findByCategory($id, $limit = '')
    {
        $limit = ($limit != '') ? "LIMIT $limit" : '';
        // 2. Tạo câu query
        $sql = parent::$connection->prepare("SELECT *
                                            FROM `category_product`
                                            INNER JOIN `products`
                                            ON `category_product`.`product_id` = `products`.`id`
                                            WHERE `category_id`=?
                                            $limit");
        $sql->bind_param('i', $id);
        // 3 & 4
        return parent::select($sql);
    }
    public function getCategories($productId)
    {
        $sql = parent::$connection->prepare("
            SELECT `category_id` 
            FROM `category_product` 
            WHERE `product_id` = ?
        ");
        $sql->bind_param('i', $productId);
        $sql->execute();
        $result = $sql->get_result();
        $categories = [];
        while ($row = $result->fetch_assoc()) {
            $categories[] = $row['category_id'];
        }
        return $categories;
    }

    public function findByKeyWord($keyword)
    {
        // 2. Tạo câu query
        $sql = parent::$connection->prepare("SELECT * FROM `products` WHERE `name` LIKE ?");
        $keyword = "%{$keyword}%";
        $sql->bind_param('s', $keyword);
        // 3 & 4
        return parent::select($sql);
    }
    //thêm sản phẩm
    public function add($name, $price, $description, $image, $category_ids): mixed
    {
        // 2. Tạo câu query
        $sql = parent::$connection->prepare("INSERT INTO `products`(`name`, `price`, `description`, `image`) VALUES (?, ?, ?, ?)");
        $sql->bind_param('siss', $name, $price, $description, $image);
        // 3 & 4
        $sql->execute();


        $productId = parent::$connection->insert_id;
        $insertPlace = str_repeat("(?, $productId), ", count($category_ids) - 1) . "(?, $productId)";
        $insertType = str_repeat('i', count($category_ids));

        $sql = parent::$connection->prepare("INSERT INTO `category_product`(`category_id`, `product_id`) VALUES $insertPlace");
        $sql->bind_param($insertType, ...$category_ids);

        return $sql->execute();
    }
    //Xóa sản phẩm 
    public function delete($productIds)
    {
        // 2. Tạo câu query
        // Tạo chuỗi kiểu ?,?,?
        $insertPlace = str_repeat("?,", count($productIds) - 1) . "?";
        // Tạo chuỗi iiiiiiii
        $insertType = str_repeat('i', count($productIds));


        $sql = parent::$connection->prepare("DELETE FROM `products` WHERE `id` IN ($insertPlace)");
        $sql->bind_param($insertType, ...$productIds);
        // 3 & 4
        return $sql->execute();
    }
    
    public function deleteBin($productId)
    {
        // 2. Tạo câu query
        $sql = parent::$connection->prepare("UPDATE `products` SET `status`= 0 WHERE `id`=?");
        $sql->bind_param('i', $productId);
        // 3 & 4
        return $sql->execute();
    }
   
    public function restore($productIds)
    {
        // 2. Tạo câu query
        // Tạo chuỗi kiểu ?,?,?
        $insertPlace = str_repeat("?,", count($productIds) - 1) . "?";
        // Tạo chuỗi iiiiiiii
        $insertType = str_repeat('i', count($productIds));

        $sql = parent::$connection->prepare("UPDATE `products` SET `status`=1 WHERE `id` IN ($insertPlace)");
        $sql->bind_param($insertType, ...$productIds);
        // 3 & 4
        return $sql->execute();
    }
     //update sản phẩm
     public function update($id, $name, $price, $description, $image, $category_ids)
     {
         $sql = parent::$connection->prepare("
         UPDATE `products`
         SET `name` = ?, `price` = ?, `description` = ?, `image` = ?
         WHERE `id` = ?
     ");
         $sql->bind_param('sissi', $name, $price, $description, $image, $id);
         $sql->execute();
 
         $sql = parent::$connection->prepare("
         DELETE FROM `category_product`
         WHERE `product_id` = ?
     ");
         $sql->bind_param('i', $id);
         $sql->execute();
 
         foreach ($category_ids as $categoryId) {
             $sql = parent::$connection->prepare("
             INSERT INTO `category_product` (`category_id`, `product_id`)
             VALUES (?, ?)
         ");
             $sql->bind_param('ii', $categoryId, $id);
             $sql->execute();
         }
 
         return true;
     }

}
