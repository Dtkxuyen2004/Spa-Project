<?php

session_start();
require_once 'config/database.php';
spl_autoload_register(callback: function ($className) {
	require_once "app/model/$className.php";
});

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	if (!empty($_POST['username']) && !empty($_POST['email']) && !empty($_POST['password']) && !empty($_POST['confirm_password'])) {
		$userModel = new User();
		$username = trim($_POST["username"]);
		$email = trim($_POST["email"]);
		$password = trim($_POST["password"]);
		$confirmPassword = trim($_POST["confirm_password"]);

		if ($password !== $confirmPassword) {
			$message = "Mật khẩu và Xác nhận mật khẩu không khớp.";
			header("Location: " . $_SERVER['PHP_SELF'] . "?message=" . urlencode($message));
			exit();
		}

		// Gọi phương thức register
		if ($userModel->register($username, $email, $password)) {
			$message = "Đăng ký thành công. Vui lòng đăng nhập.";
			header("Location: index.php?message=" . urlencode($message));
			exit();
		} else {
			$message = "Tên đăng nhập hoặc email đã tồn tại.";
			header("Location: " . $_SERVER['PHP_SELF'] . "?message=" . urlencode($message));
			exit();
		}
	} else {
		$message = "Vui lòng điền đầy đủ thông tin.";
		header("Location: http://localhost/QuanLyTiemNails/QuanLyTiemNails/admin/main/ " . $_SERVER['PHP_SELF'] . "?message=" . urlencode($message));
		exit();
	}
}
?>
<!DOCTYPE html>
<html lang="vi">

<head>
	<title>Trang đăng ký</title>
	<meta charset="utf-8">
	<!-- Bootstrap CSS -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
	<style>
		body {
			background-color: #f8f9fa;
		}

		.card-header {
			background-color: #00564e;
			color: white;
		}

		.btn-primary {
			background-color: #00564e;
			border-color: #00564e;
		}

		.btn-primary:hover {
			background-color: #004d46;
			border-color: #004d46;
		}

		.btn-outline-secondary {
			color: #00564e;
			border-color: #00564e;
		}

		.btn-outline-secondary:hover {
			background-color: #00564e;
			color: white;
		}

		.alert-success {
			background-color: #d4edda;
			color: #155724;
			border-color: #c3e6cb;
		}

		.alert-danger {
			background-color: #f8d7da;
			color: #721c24;
			border-color: #f5c6cb;
		}
	</style>
</head>

<body>
	<div class="container mt-5">
		<div class="row justify-content-center">
			<div class="col-md-6">
				<div class="card shadow">
					<div class="card-header text-center">
						<h4>Đăng Ký</h4>
					</div>
					<div class="card-body">
						<form method="POST" action="">
							<div class="mb-3">
								<label for="username" class="form-label">Tên đăng nhập</label>
								<input type="text" name="username" id="username" class="form-control" required>
							</div>
							<div class="mb-3">
								<label for="email" class="form-label">Email</label>
								<input type="email" name="email" id="email" class="form-control" required>
							</div>
							<div class="mb-3">
								<label for="password" class="form-label">Mật khẩu</label>
								<div class="input-group">
									<input type="password" name="password" id="password" class="form-control" required>
									<button type="button" class="btn btn-outline-secondary" id="togglePassword">
										Hiển thị
									</button>
								</div>
							</div>
							<div class="mb-3">
								<label for="confirm_password" class="form-label">Xác nhận mật khẩu</label>
								<input type="password" name="confirm_password" id="confirm_password" class="form-control" required>
							</div>
							<div class="text-center">
								<button type="submit" name="Register" class="btn btn-primary w-100">Đăng ký</button>
							</div>
                            <div class="text-center mt-3">
    <small>
        Quay lại trang 
        <a href="index.php" class="text-decoration-none" style="color: #00564e;">Đăng Nhập </a>
    </small>
<trang 
						</form>
						<?php
						// Hiển thị thông báo (nếu có)
						if (isset($_GET['message'])) {
							$alertType = strpos($_GET['message'], 'thành công') !== false ? 'alert-success' : 'alert-danger';
							echo "<div class='alert $alertType text-center mt-3'>" . htmlspecialchars($_GET['message']) . "</div>";
						}
						?>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Bootstrap JS -->
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
	<script>
		// Tính năng hiển thị mật khẩu
		document.getElementById('togglePassword').addEventListener('click', function () {
			const passwordField = document.getElementById('password');
			const isPasswordHidden = passwordField.type === 'password';

			// Chuyển đổi thuộc tính type
			passwordField.type = isPasswordHidden ? 'text' : 'password';

			// Thay đổi text của nút
			this.textContent = isPasswordHidden ? 'Ẩn' : 'Hiển thị';
		});
	</script>
</body>

</html>
