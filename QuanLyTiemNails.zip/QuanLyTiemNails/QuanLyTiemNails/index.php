<?php
session_start();
require_once 'config/database.php';
spl_autoload_register(callback: function ($className) {
	require_once "app/model/$className.php";
});
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	if (!empty($_POST['username']) && !empty($_POST['password'])) {
		$userModel = new User();
		$username = trim($_POST["username"]);
		$password = trim($_POST["password"]);

		// Kiểm tra thông tin đăng nhập
		if ($userModel->findLogin($username, $password)) {
			$result = $userModel->getUserlogin($username, $password);
			$_SESSION['user'] = $result[0]['username'];
			$_SESSION['email'] = $result[0]['email'];
			$_SESSION['userId'] = $result[0]['id'];
			$_SESSION['phone'] = $result[0]['phone'];
			header('Location: http://localhost/QuanLyTiemNails/QuanLyTiemNails/admin/main/');
		} else {
			$message = "Tên đăng nhập hoặc mật khẩu không đúng.";
			// Chuyển hướng để tránh refresh gửi lại form
			header("Location: " . $_SERVER['PHP_SELF'] . "?message=" . urlencode($message));
			exit();
		}
	}
	if (isset($_GET['message'])) {
		$alertType = strpos($_GET['message'], 'thành công') !== false ? 'alert-success' : 'alert-danger';
		echo "<div class='alert $alertType text-center mt-3'>" . htmlspecialchars($_GET['message']) . "</div>";
	}
	if (is_array($result) && count($result) > 0 && isset($result[0]['username'])) {
		$_SESSION['user'] = $result[0]['username'];
	} else {
		$message = "Lỗi: Không thể lấy thông tin người dùng.";
		header("Location: " . $_SERVER['PHP_SELF'] . "?message=" . urlencode($message));
		exit();
	}

}
?>
<!DOCTYPE html>
<html lang="vi">

<head>
	<title>Trang đăng nhập</title>
	<meta charset="utf-8">
	<!-- Bootstrap CSS -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
	<style>
		/* Màu nền và text */
		body {
			background-color: #f8f9fa;
			/* Màu nền nhạt */
		}

		.card-header {
			background-color: #00564e;
			/* Màu xanh mong muốn */
			color: white;
		}

		.btn-primary {
			background-color: #00564e;
			border-color: #00564e;
		}

		.btn-primary:hover {
			background-color: #004d46;
			border-color: #004d46;
		}

		.btn-outline-secondary {
			color: #00564e;
			border-color: #00564e;
		}

		.btn-outline-secondary:hover {
			background-color: #00564e;
			color: white;
		}

		.alert-success {
			background-color: #d4edda;
			color: #155724;
			border-color: #c3e6cb;
		}

		.alert-danger {
			background-color: #f8d7da;
			color: #721c24;
			border-color: #f5c6cb;
		}
	</style>
</head>

<body>
	<div class="container mt-5">
		<div class="row justify-content-center">
			<div class="col-md-6">
				<div class="card shadow">
					<div class="card-header text-center">
						<h4>Đăng Nhập</h4>
					</div>
					<div class="card-body">
						<form method="POST" action="">
							<div class="mb-3">
								<label for="username" class="form-label">Tên đăng nhập</label>
								<input type="text" name="username" id="username" class="form-control" required>
							</div>
							<div class="mb-3">
								<label for="password" class="form-label">Mật khẩu</label>
								<div class="input-group">
									<input type="password" name="password" id="password" class="form-control" required>
									<button type="button" class="btn btn-outline-secondary" id="togglePassword">
										Hiển thị
									</button>
								</div>
							</div>
							<div class="text-center">
								<button type="submit" name="Login" class="btn btn-primary w-100">Đăng nhập</button>

							</div>
							<div class="text-center mt-3">
								<small>
									Bạn chưa có tài khoản?
									<a href="register.php" class="text-decoration-none" style="color: #00564e;">Đăng ký
										ngay</a>
								</small>
								<br>
								<small>
									Quên mật khẩu?
									<a href="fogot_password.php" class="text-decoration-none"
										style="color: #00564e;">Đặt lại mật khẩu</a>
								</small>
							</div>

						</form>
						<?php
						// Hiển thị thông báo (nếu có)
						if (isset($_GET['message'])) {
							$alertType = strpos($_GET['message'], 'thành công') !== false ? 'alert-success' : 'alert-danger';
							echo "<div class='alert $alertType text-center mt-3'>" . htmlspecialchars($_GET['message']) . "</div>";
						}
						?>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Bootstrap JS -->
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
	<script>
		// Tính năng hiển thị mật khẩu
		document.getElementById('togglePassword').addEventListener('click', function () {
			const passwordField = document.getElementById('password');
			const isPasswordHidden = passwordField.type === 'password';

			// Chuyển đổi thuộc tính type
			passwordField.type = isPasswordHidden ? 'text' : 'password';

			// Thay đổi text của nút
			this.textContent = isPasswordHidden ? 'Ẩn' : 'Hiển thị';
		});
	</script>
</body>

</html>