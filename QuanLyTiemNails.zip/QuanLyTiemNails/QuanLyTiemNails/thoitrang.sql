
-- Tạo cơ sở dữ liệu
CREATE DATABASE IF NOT EXISTS `product_management`;
USE `product_management`;

-- Tạo bảng categories
CREATE TABLE `categories` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(255) NOT NULL
);

-- Dữ liệu mẫu cho categories
INSERT INTO `categories` (`name`) VALUES 
('Quần'),
('Áo'),
('Váy'),
('Chân váy/Quần Soft');

-- Tạo bảng products
CREATE TABLE `products` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(255) NOT NULL,
    `price` DECIMAL(10, 2) NOT NULL,
    `description` TEXT,
    `image` VARCHAR(255),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Dữ liệu mẫu cho products
INSERT INTO `products` (`name`, `price`, `description`, `image`) VALUES
('Quần Jean Rách', 499000, 'Quần Jean thời trang rách gối, phù hợp với phong cách cá tính', 'quan_jean_rach.jpg'),
('Áo Thun Trơn', 199000, 'Áo thun cotton cao cấp, mềm mịn và thoải mái', 'ao_thun_tron.jpg'),
('Váy Xòe Hoa Nhí', 399000, 'Váy xòe họa tiết hoa nhí, thích hợp cho mùa hè', 'vay_xoe_hoa_nhi.jpg'),
('Chân Váy Caro', 299000, 'Chân váy caro phong cách Hàn Quốc, phối dễ dàng với áo thun hoặc sơ mi', 'chan_vay_caro.jpg'),
('Quần Soft Lụa', 359000, 'Quần Soft làm từ lụa mềm mại, phù hợp mặc đi làm hoặc đi chơi', 'quan_soft_lua.jpg');

-- Tạo bảng category_product (liên kết nhiều-nhiều)
CREATE TABLE `category_product` (
    `category_id` INT NOT NULL,
    `product_id` INT NOT NULL,
    PRIMARY KEY (`category_id`, `product_id`),
    FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE
);

-- Dữ liệu mẫu cho category_product
INSERT INTO `category_product` (`category_id`, `product_id`) VALUES
(1, 1), -- Quần - Quần Jean Rách
(2, 2), -- Áo - Áo Thun Trơn
(3, 3), -- Váy - Váy Xòe Hoa Nhí
(4, 4), -- Chân váy/Quần Soft - Chân Váy Caro
(4, 5); -- Chân váy/Quần Soft - Quần Soft Lụa
