<?php
require_once '../../config/database.php';
spl_autoload_register(function ($className) {
    require_once "../../app/model/$className.php";
});
$loginUrl = 'http://localhost/QuanLyTiemNails/QuanLyTiemNails/index.php';

if (!empty($_POST['name']) && !empty($_POST['price']) && !empty($_POST['duration'])) {
    $serviceModel = new Service();
    $name = $_POST['name'];
    $price = $_POST['price'];
    $duration = $_POST['duration'];
    $category_id = $_POST['category_id'];

    if ($serviceModel->add($name, $price, $duration, $category_id))
        header('Location: http://localhost/QuanLyTiemNails/QuanLyTiemNails/admin/services/');
}

$categoryModel = new Category();
$categories = $categoryModel->all();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lani Nails Spa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        /* Đảm bảo Footer luôn ở cuối trang */
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
        }

        main {
            flex: 1;
        }

        footer {
            background-color: #00564e;
            color: white;
            padding: 10px 0;
            text-align: center;
        }

        .navbar {
            background-color: #00564e;
        }

        .navbar-brand,
        .nav-link {
            color: white !important;
        }

        /* Card Styling */
        .card {
            display: flex;
            flex-direction: row;
            align-items: center;
            padding: 15px;
            transition: transform 0.3s ease-in-out;
        }

        .card:hover {
            transform: scale(1.05);
        }

        .card img {
            width: 30%;
            height: 30%;
            object-fit: cover;
            margin-right: 20px;
        }

        .card-title {
            margin: 0;
            text-align: left;
            color: #00564e;
            font-size: 1.25rem;
        }

        .card-link {
            text-decoration: none;
            color: inherit;
        }
    </style>
</head>

<body>
    <!-- Thanh Điều Hướng -->
    <?php include '../../includes/header.php'; ?>
    <main>
        <div class="container">
            <div class="back-button">
                <a href="./" class="btn btn-secondary">&larr; Quay Lại</a>
            </div>
            <h1>Thêm Dịch Vụ</h1>
            <form action="add.php" method="post">
                <div class="mb-3">
                    <label for="name" class="form-label">Tên dịch vụ</label>
                    <input type="text" class="form-control" id="name" name="name">
                </div>
                <div class="mb-3">
                    <label for="price" class="form-label">Giá</label>
                    <input type="number" class="form-control" id="price" name="price">
                </div>
                <div class="mb-3">
                    <label for="description" class="form-label">Thời gian dịch vụ</label>
                    <input type="number" class="form-control" id="duration" name="duration">
                </div>
                <div class="mb-3">
                    <label for="categories" class="form-label">Danh mục</label>
                    <select class="form-select" name="category_id" aria-label="Select category">
                        <option value="" disabled selected>Chọn danh mục</option>
                        <?php foreach ($categories as $category): ?>
                            <option value="<?php echo htmlspecialchars($category['id']); ?>">
                                <?php echo htmlspecialchars($category['category_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Thêm</button>
            </form>
        </div>
    </main>
    <!-- Footer -->
    <?php include '../../includes/footer.php'; ?>
</body>

</html>