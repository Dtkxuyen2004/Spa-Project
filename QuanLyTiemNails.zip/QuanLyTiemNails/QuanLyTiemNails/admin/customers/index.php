<?php
$loginUrl = 'http://localhost/QuanLyTiemNails/QuanLyTiemNails/index.php';
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: $loginUrl");
    exit();
}
require_once '../../config/database.php';
spl_autoload_register(function ($className) {
    require_once "../../app/model/$className.php";
});
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;

// Fetch customers
$customerModel = new Customer();
$customers = $customerModel->all();
// Xác định trang hiện tại từ URL, nếu không có thì mặc định là trang 1
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $limit;

// Tính tổng số khách hàng trong cơ sở dữ liệu
$customerModel = new Customer();
$totalCustomers = $customerModel->countCustomers();

// Tính tổng số trang
$totalPages = ceil($totalCustomers / $limit);

// Lấy danh sách khách hàng với LIMIT và OFFSET
$customers = $customerModel->getCustomers($limit, $start);


// Fetch total customers based on search query
$search = isset($_GET['search']) ? trim($_GET['search']) : ''; // Lấy từ GET và loại bỏ khoảng trắng thừa

if (!empty($search)) {
    $totalCustomers = $customerModel->countCustomersByName($search);
    $customers = $customerModel->searchCustomersByName($search, $limit, $start);
} else {
    $totalCustomers = $customerModel->countCustomers();
    $customers = $customerModel->getCustomers($limit, $start);
}


// Handle delete action
if (isset($_POST['customerId'])) {
    if ($customerModel->delete($_POST['customerId'])) {
        header('Location: index.php');
        exit();
    }
}

// Helper function to render categories
function renderCategories($category_name)
{
    if (empty($category_name)) {
        return '';
    }
    return implode('', array_map(function ($e) {
        return "<span class='badge text-bg-warning'>$e</span>";
    }, explode(',', $category_name)));
}
// Số lượng khách hàng mỗi trang, mặc định là 10

?>
<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản Lý Khách Hàng</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
        }

        main {
            flex: 1;
        }

        footer {
            background-color: #00564e;
            color: white;
            text-align: center;
            padding: 10px 0;
            flex-shrink: 0;
        }

        .navbar {
            background-color: #00564e;
        }

        .navbar-brand,
        .nav-link {
            color: white !important;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <?php include '../../includes/header.php'; ?>
    <!-- Main Content -->
    <main>
        <div class="container my-4">
            <div class="back-button">
                <a href="../main/index.php" class="btn btn-secondary">&larr; Quay Lại</a>
            </div>
            <h1>
                Quản Lý Khách Hàng
                <a href="add.php" class="btn btn-outline-primary"><i class="fa fa-plus-square"></i> Thêm khách hàng</a>
            </h1>
            <form method="get" class="d-flex align-items-center my-3" style="max-width: 400px; margin: 0 auto;">
    <input type="text" name="search" class="form-control form-control-sm" placeholder="Tìm kiếm" value="<?php echo htmlspecialchars($search); ?>" style="flex: 1; margin-right: 5px;">
    <button type="submit" class="btn btn-sm btn-primary">Tìm</button>
</form>


           
            <table class="table table-striped table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>STT</th>
                        <th>Tên khách hàng</th>
                        <th>Điện thoại</th>
                        <th>Email</th>
                        <th>Địa chỉ</th>
                        <th>Tùy chỉnh</th>
                    </tr>
                </thead>
                <tbody>
                    
                    <?php 
                    $stt = $start + 1;
                    foreach ($customers as $customer): ?>
                        <tr>
                            <td><?php echo $stt++;?> </td>
                            <td><?php echo $customer['customer_name']; ?></td>
                            <td><?php echo $customer['phone']; ?></td>
                            <td><?php echo $customer['email']; ?></td>
                            <td><?php echo $customer['address']; ?></td>
                            <td>
                                <a href="edit.php?customer_id=<?php echo $customer['id']; ?>"
                                    class="btn btn-outline-primary">
                                    <i class="far fa-edit"></i> Chỉnh sửa
                                </a>
                                <!-- Delete Button Trigger -->
                                <button type="button" class="btn btn-outline-danger" data-bs-toggle="modal"
                                    data-bs-target="#deleteModal-<?php echo $customer['id']; ?>">
                                    <i class="fa-solid fa-trash"></i> Xóa
                                </button>

                                <!-- Delete Confirmation Modal -->
                                <div class="modal fade" id="deleteModal-<?php echo $customer['id']; ?>" tabindex="-1"
                                    aria-labelledby="deleteModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="deleteModalLabel">Xác nhận xóa</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                Bạn có chắc chắn muốn xóa khách hàng này không?
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-bs-dismiss="modal">Hủy</button>
                                                <form action="index.php" method="post" style="display: inline;">
                                                    <input type="hidden" name="customerId"
                                                        value="<?php echo $customer['id']; ?>">
                                                    <button type="submit" class="btn btn-danger">Xác nhận</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>



          
            <!-- Phân trang -->
            <nav>
                <ul class="pagination justify-content-center">
                    <!-- Mũi tên đến trang đầu tiên -->
                        <li class="page-item <?php if ($page <= 1) echo 'disabled'; ?>">
                            <a class="page-link" href="?page=1&limit=<?php echo $limit; ?>" aria-label="First">
                                &laquo; <!-- Mũi tên trái kép -->
                            </a>
                        </li>
        
                    <!-- Mũi tên đến trang trước -->
                    <li class="page-item <?php if ($page <= 1) echo 'disabled'; ?>">
                        <a class="page-link" href="?page=<?php echo $page - 1; ?>&limit=<?php echo $limit; ?>" aria-label="Previous">
                            &lt; <!-- Mũi tên trái -->
                        </a>
                    </li>

                    <!-- Hiển thị số trang -->
                    <?php 
                    // Hiển thị các số trang trước và sau trang hiện tại
                    for ($i = 1; $i <= $totalPages; $i++) {
                        if ($i == $page) {
                            echo "<li class='page-item active'><a class='page-link' href='?page=$i&limit=$limit'>$i</a></li>";
                        } else {
                            echo "<li class='page-item'><a class='page-link' href='?page=$i&limit=$limit'>$i</a></li>";
                        }
                    }
                    ?>

                    <!-- Mũi tên đến trang sau -->
                    <li class="page-item <?php if ($page >= $totalPages) echo 'disabled'; ?>">
                        <a class="page-link" href="?page=<?php echo $page + 1; ?>&limit=<?php echo $limit; ?>" aria-label="Next">
                            &gt; <!-- Mũi tên phải -->
                        </a>
                    </li>

                    <!-- Mũi tên đến trang cuối cùng -->
                    <li class="page-item <?php if ($page >= $totalPages) echo 'disabled'; ?>">
                        <a class="page-link" href="?page=<?php echo $totalPages; ?>&limit=<?php echo $limit; ?>" aria-label="Last">
                            &raquo; <!-- Mũi tên phải kép -->
                        </a>
                    </li>
                </ul>
            </nav>

            <!-- Lựa chọn số lượng khách hàng mỗi trang -->
            <form method="get" class="d-flex my-3 align-items-center" style="max-width: 120px;">
                <select id="limit" name="limit" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="5" <?php if ($limit == 5) echo 'selected'; ?>>5</option>
                    <option value="10" <?php if ($limit == 10) echo 'selected'; ?>>10</option>
                    <option value="15" <?php if ($limit == 15) echo 'selected'; ?>>15</option>
                </select>
            </form>
        </div>
    </main>

    <!-- Footer -->
    <?php include '../../includes/footer.php'; ?>
</body>

</html>