<?php
require_once '../../config/database.php';
spl_autoload_register(function ($className) {
    require_once "../../app/model/$className.php";
});
$loginUrl = 'http://localhost/QuanLyTiemNails/QuanLyTiemNails/index.php';
$status = '';

$customerModel = new Customer();
$customerId = '';
if (!empty($_GET['customer_id'])) {
    $customerId = $_GET['customer_id'];
    $customer = $customerModel->find($customerId);
    $customerId = $customer['id'];
}

if (!empty($_POST['customer_id'])) {
    // Validate phone number (only numeric characters allowed)
    $phone = $_POST['phone'];
    if (!preg_match('/^\d+$/', $phone)) {
        $status = 'invalid_phone';
    } else {
        $customer_id = $_POST['customer_id'];
        $customer_name = $_POST['customer_name'];
        $email = $_POST['email'];
        $address = $_POST['address'];

        if ($customerModel->update($customer_id, $customer_name, $email, $phone, $address)) {
            header('Location: http://localhost/QuanLyTiemNails/QuanLyTiemNails/admin/customers/');
            exit;
        } else {
            echo "Failed to update the customer.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
        }

        main {
            flex: 1;
        }

        footer {
            background-color: #00564e;
            color: white;
            text-align: center;
            padding: 10px 0;
            flex-shrink: 0;
        }

        .navbar {
            background-color: #00564e;
        }

        .navbar-brand,
        .nav-link {
            color: white !important;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <?php include '../../includes/header.php'; ?>
    <main>
        <div class="container">
            <div class="back-button">
                <a href="./" class="btn btn-secondary">&larr; Quay Lại</a>
            </div>
            <h1>Chỉnh Sửa Thông Tin Khách Hàng</h1>
            <form action="edit.php?customer_id=<?php echo $customerId ?>&phone=<?php $customer['phone'] ?>" method="post">
                <input type="hidden" name="customer_id" value="<?php echo $customer['id']; ?>">
                <div class="mb-3">
                    <label for="name" class="form-label">Tên khách hàng</label>
                    <input type="text" class="form-control" id="customer_name" name="customer_name"
                        value="<?php echo $customer['customer_name']; ?>">
                </div>
                <div class="mb-3">
                    <label for="price" class="form-label">Email</label>
                    <input type="text" class="form-control" id="email" name="email"
                        value="<?php echo $customer['email']; ?>">
                </div>
                <div class="mb-3">
                    <label for="duration" class="form-label">Số điện thoại</label>
                    <input type="text" class="form-control" id="phone" name="phone"
                        value="<?php echo $customer['phone']; ?>">
                </div>
                <div class="mb-3">
                    <label for="duration" class="form-label">Địa chỉ</label>
                    <input type="text" class="form-control" id="address" name="address"
                        value="<?php echo $customer['address']; ?>">
                </div>
                <button type="submit" class="btn btn-primary">Cập Nhật</button>
            </form>

        </div>
    </main>
    <!-- JavaScript Block -->
    <script>
        const status = "<?php echo $status; ?>"; // Pass PHP variable to JavaScript

        if (status === "duplicate") {
            alert("Số điện thoại đã tồn tại, vui lòng chọn số khác.");
        } else if (status === "invalid_phone") {
            alert("Số điện thoại chỉ được chứa số.");
        } else if (status === "success") {
            alert("Thêm khách hàng thành công.");
        }
    </script>

    <!-- Footer -->
    <?php include '../../includes/footer.php'; ?>
</body>

</html>