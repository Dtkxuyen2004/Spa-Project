<?php
$loginUrl = 'http://localhost/QuanLyTiemNails/QuanLyTiemNails/index.php';
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: $loginUrl");
    exit();
}
require_once '../../config/database.php';
spl_autoload_register(callback: function ($className) {
    require_once "../../app/model/$className.php";
});

// Lấy sản phẩm cùng với danh mục
$serviceModel = new Customer();
$services = $serviceModel->all();

// Xóa Dịch Vụ
if (isset($_POST['serviceId'])) {
    // var_dump($_POST['serviceId']);
    if ($serviceModel->delete($_POST['serviceId']))
    header('Location: http://localhost/QuanLyTiemNails/QuanLyTiemNails/admin/services/');
}
?>


<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Shop</title>
    <link rel="stylesheet" href="public/css/styles.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Đảm bảo Footer luôn ở cuối trang */
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
        }

        main {
            flex: 1;
        }

        footer {
            background-color: #00564e;
            color: white;
            padding: 10px 0;
            text-align: center;
        }

        .navbar {
            background-color: #00564e;
        }

        .navbar-brand,
        .nav-link {
            color: white !important;
        }

        /* Card Styling */
        .card {
            display: flex;
            flex-direction: row;
            align-items: center;
            padding: 15px;
            transition: transform 0.3s ease-in-out;
        }

        .card:hover {
            transform: scale(1.05);
        }

        .card img {
            width: 30%;
            height: 30%;
            object-fit: cover;
            margin-right: 20px;
        }

        .card-title {
            margin: 0;
            text-align: left;
            color: #00564e;
            font-size: 1.25rem;
        }

        .card-link {
            text-decoration: none;
            color: inherit;
        }
    </style>
</head>

<body>
    <!-- Thanh Điều Hướng -->
    <?php include '../../includes/header.php'; ?>
    <div class="container">
        <h1>
            Quản Lý Danh Mục - Dịch Vụ
            <a href="#" class="btn btn-outline-primary"><i class="fa fa-plus-square"></i> Thêm danh mục</a>
            <a href="add.php" class="btn btn-outline-primary"><i class="fa fa-plus-square"></i> Thêm dịch vụ</a>
        </h1>
        <table class="table">
            <thead>
                <tr>
                    <th>Danh mục</th>
                    <th>Tên dịch vụ</th>
                    <th>Giá</th>
                    <th>Tùy chỉnh</th>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($services as $service):
                    ?>
                    <tr>
                        <td>
                            <?php

                            echo (!empty($service['category_name'])) ? implode(array_map(function ($e) {
                                return "<span class='badge text-bg-warning'>$e</span>";
                            }, explode(',', $service['category_name']))) : '';

                            ?>
                        </td>
                        <td><?php echo $service['service_name'] ?></td>
                        <td><?php echo $service['price'] ?></td>
                        <td>
                            <a href="edit.php?category_id=<?php echo $service['id'] ?>&service_id=<?php echo $service['service_id'] ?>&name=<?php echo $service['service_name'] ?>&price=<?php echo $service['price'] ?>"
                                class="btn btn-outline-primary">
                                <i class="far fa-edit"></i> Chỉnh sửa
                            </a>
                            <form action="index.php" method="post" onsubmit="return confirm('Bạn xác nhận xóa dịch vụ này?')"
                                style="display: inline-flex; align-items: center;">
                                <input type="hidden" name="serviceId" value="<?php echo $service['service_id'] ?>">
                                <button type="submit" class="btn btn-outline-danger">
                                    <i class="fa-solid fa-trash"></i> Xóa
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php
                endforeach;
                ?>

            </tbody>
        </table>
    </div>
    <!-- Footer -->
    <?php include '../../includes/footer.php'; ?>
</body>

</html>