<?php
require_once '../../config/database.php';
spl_autoload_register(function ($className) {
    require_once "../../app/model/$className.php";
});

$serviceModel = new Service();
$categoryModel = new Category();
$serviceId = '';
$categoryId = '';
if (!empty($_GET['service_id'])) {
    $serviceId = $_GET['service_id'];
    $categoryId = $_GET['category_id'];
    $service = $serviceModel->find($serviceId);
    $categories = $categoryModel->all();
    $serviceCategories = $serviceModel->getCategories($serviceId);

    $serviceId = $service['id'];
}

// if (!empty($_POST['service_id']) && !empty($_POST['category_id'])) {
//     echo $_POST['service_id'];
//     $service_id = $_POST['service_id'];
//     $service_name = $service['service_name'];
//     $price = $service['price'];
//     $duration = $service['service_duration'];
//     $category_ids = $_POST['category_id'];

//     if ($serviceModel->update($service_id, $service_name, $price, $duration, $category_ids)) {
//         header('Location: http://localhost/QuanLyTiemNails/QuanLyTiemNails/admin/services/');
//     }
// }
if (!empty($_POST['service_id']) && !empty($_POST['category_id'])) {
    $service_id = $_POST['service_id'];
    $service_name = $_POST['name']; // Use the updated service name
    $price = $_POST['price'];       // Use the updated price
    $duration = $_POST['duration']; // Use the updated duration
    $category_id = $_POST['category_id']; // Single category ID

    if ($serviceModel->update($service_id, $service_name, $price, $duration, $category_id)) {
        header('Location: http://localhost/QuanLyTiemNails/QuanLyTiemNails/admin/services/');
        exit;
    } else {
        echo "Failed to update the service.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<style>
    textarea {
        resize: vertical;
        max-height: 300px;
        overflow-y: auto;
    }
</style>

<body>
    <div class="container">
        <h1>Chỉnh Sửa Dịch Vụ</h1>
        <form action="edit.php?service_id=<?php echo $serviceId ?>&category_id=<?php echo $categoryId ?>" method="post">
            <input type="hidden" name="service_id" value="<?php echo $service['id']; ?>">
            <div class="mb-3">
                <label for="name" class="form-label">Tên dịch vụ</label>
                <input type="text" class="form-control" id="name" name="name"
                    value="<?php echo $service['service_name']; ?>">
            </div>
            <div class="mb-3">
                <label for="price" class="form-label">Giá</label>
                <input type="number" class="form-control" id="price" name="price"
                    value="<?php echo $service['price']; ?>">
            </div>
            <div class="mb-3">
                <label for="duration" class="form-label">Thời gian dịch vụ</label>
                <input type="number" class="form-control" id="duration" name="duration"
                    value="<?php echo $service['service_duration']; ?>">
            </div>
            <!-- <div class="mb-3">
                <label for="categories" class="form-label">Danh mục</label>
                <select class="form-select" name="category_id" aria-label="Select category">
                    <option value="" disabled>Chọn danh mục</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?php echo htmlspecialchars($category['id']); ?>"
                            <?php echo ($category['id'] == $categoryId) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($category['category_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div> -->
            <div class="mb-3">
                <label for="categories" class="form-label">Danh mục</label>
                <select class="form-select" name="category_id" aria-label="Select category">
                    <option value="" disabled>Chọn danh mục</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?php echo htmlspecialchars($category['id']); ?>"
                            <?php echo ($category['id'] == $categoryId) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($category['category_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Cập Nhật</button>
        </form>

    </div>
</body>

</html>