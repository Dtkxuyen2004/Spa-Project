<?php
session_start();
$loginUrl = 'http://localhost/QuanLyTiemNails/QuanLyTiemNails/index.php';

if (!isset($_SESSION['user'])) {
    header("Location: $loginUrl");
    exit();
}
require_once '../../config/database.php';
spl_autoload_register(callback: function ($className) {
    require_once "../../app/model/$className.php";
});
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;

// Lấy sản phẩm cùng với danh mục
$staffModel = new Staff();
$staffs = $staffModel->all();
// Xác định trang hiện tại từ URL, nếu không có thì mặc định là trang 1
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $limit;

// Tính tổng số khách hàng trong cơ sở dữ liệu
$staffModel = new Staff();
$totalStaffs = $staffModel->countStaffs();

// Tính tổng số trang
$totalPages = ceil($totalStaffs / $limit);

// Lấy danh sách khách hàng với LIMIT và OFFSET
$staffs = $staffModel->getStaffs($limit, $start);
// Fetch total customers based on search query
$search = isset($_GET['search']) ? trim($_GET['search']) : ''; // Lấy từ GET và loại bỏ khoảng trắng thừa

if (!empty($search)) {
    $totalStaffs = $staffModel->countStaffsByName($search);
    $staffs = $staffModel->searchStaffsByName($search, $limit, $start);
} else {
    $totalStaffs = $staffModel->countStaffs();
    $staffs = $staffModel->getStaffs($limit, $start);
}


if (isset($_POST['staffId'])) {
    if ($staffModel->delete($_POST['staffId'])) {
        header('Location: index.php');
        exit();
    }
}
?>


<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>lani</title>
    <link rel="stylesheet" href="public/css/styles.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Đảm bảo Footer luôn ở cuối trang */
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
        }

        main {
            flex: 1;
        }

        footer {
            background-color: #00564e;
            color: white;
            padding: 10px 0;
            text-align: center;
        }

        .navbar {
            background-color: #00564e;
        }

        .navbar-brand,
        .nav-link {
            color: white !important;
        }

        /* Card Styling */
        .card {
            display: flex;
            flex-direction: row;
            align-items: center;
            padding: 15px;
            transition: transform 0.3s ease-in-out;
        }

        .card:hover {
            transform: scale(1.05);
        }

        .card img {
            width: 30%;
            height: 30%;
            object-fit: cover;
            margin-right: 20px;
        }

        .card-title {
            margin: 0;
            text-align: left;
            color: #00564e;
            font-size: 1.25rem;
        }

        .card-link {
            text-decoration: none;
            color: inherit;
        }
    </style>
</head>

<body>
    <!-- Thanh Điều Hướng -->
    <?php include '../../includes/header.php'; ?>
    <div class="container">
        <div class="back-button">
            <a href="../main/index.php" class="btn btn-secondary">&larr; Quay Lại</a>
        </div>
        <h1>
            Quản Lý Nhân Viên
            <a href="add.php" class="btn btn-outline-primary"><i class="fa fa-plus-square"></i> Thêm nhân viên </a>
        </h1>
        <form method="get" class="d-flex align-items-center my-3" style="max-width: 400px; margin: 0 auto;">
    <input type="text" name="search" class="form-control form-control-sm" placeholder="Tìm kiếm" value="<?php echo htmlspecialchars($search); ?>" style="flex: 1; margin-right: 5px;">
    <button type="submit" class="btn btn-sm btn-primary">Tìm</button>
</form>
        <table class="table table-striped table-hover">
                <thead class="table-dark">
                <tr>
                     <th>STT</th>
                    <th>Tên nhân viên</th>
                    <th>Số điện thoại</th>
                    <th>Email</th>
                    <th>Chức Vụ</th>
                    <th>Tùy chỉnh</th>
                </tr>
            </thead>
            <tbody>
                <?php
                  $stt = 1;
                foreach ($staffs as $staff):
                    ?>
                    <tr>
                         <td><?php echo $stt++; ?></td>
                        <td><?php echo $staff['name'] ?></td>
                        <td><?php echo $staff['phone'] ?></td>
                        <td><?php echo $staff['email'] ?></td>
                        <td><?php echo $staff['chucvu'] ?></td>
                        <td>
                        <a href="edit.php?staff_id=<?php echo $staff['id']; ?>"
                                    class="btn btn-outline-primary">
                                    <i class="far fa-edit"></i> Chỉnh sửa
                                </a>
                                <!-- Delete Button Trigger -->
                                <button type="button" class="btn btn-outline-danger" data-bs-toggle="modal"
                                    data-bs-target="#deleteModal-<?php echo $staff['id']; ?>">
                                    <i class="fa-solid fa-trash"></i> Xóa
                                </button>

                                <!-- Delete Confirmation Modal -->
                                <div class="modal fade" id="deleteModal-<?php echo $staff['id']; ?>" tabindex="-1"
                                    aria-labelledby="deleteModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="deleteModalLabel">Xác nhận xóa</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                Bạn có chắc chắn muốn xóa khách hàng này không?
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-bs-dismiss="modal">Hủy</button>
                                                <form action="index.php" method="post" style="display: inline;">
                                                    <input type="hidden" name="staffId"
                                                        value="<?php echo $staff['id']; ?>">
                                                    <button type="submit" class="btn btn-danger">Xác nhận</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                        </td>
                    </tr>
                    <?php
                endforeach;
                ?>
            </tbody>
        </table>
        <!-- Phân trang -->
        <nav>
                <ul class="pagination justify-content-center">
                    <!-- Mũi tên đến trang đầu tiên -->
                        <li class="page-item <?php if ($page <= 1) echo 'disabled'; ?>">
                            <a class="page-link" href="?page=1&limit=<?php echo $limit; ?>" aria-label="First">
                                &laquo; <!-- Mũi tên trái kép -->
                            </a>
                        </li>
        
                    <!-- Mũi tên đến trang trước -->
                    <li class="page-item <?php if ($page <= 1) echo 'disabled'; ?>">
                        <a class="page-link" href="?page=<?php echo $page - 1; ?>&limit=<?php echo $limit; ?>" aria-label="Previous">
                            &lt; <!-- Mũi tên trái -->
                        </a>
                    </li>

                    <!-- Hiển thị số trang -->
                    <?php 
                    // Hiển thị các số trang trước và sau trang hiện tại
                    for ($i = 1; $i <= $totalPages; $i++) {
                        if ($i == $page) {
                            echo "<li class='page-item active'><a class='page-link' href='?page=$i&limit=$limit'>$i</a></li>";
                        } else {
                            echo "<li class='page-item'><a class='page-link' href='?page=$i&limit=$limit'>$i</a></li>";
                        }
                    }
                    ?>

                    <!-- Mũi tên đến trang sau -->
                    <li class="page-item <?php if ($page >= $totalPages) echo 'disabled'; ?>">
                        <a class="page-link" href="?page=<?php echo $page + 1; ?>&limit=<?php echo $limit; ?>" aria-label="Next">
                            &gt; <!-- Mũi tên phải -->
                        </a>
                    </li>

                    <!-- Mũi tên đến trang cuối cùng -->
                    <li class="page-item <?php if ($page >= $totalPages) echo 'disabled'; ?>">
                        <a class="page-link" href="?page=<?php echo $totalPages; ?>&limit=<?php echo $limit; ?>" aria-label="Last">
                            &raquo; <!-- Mũi tên phải kép -->
                        </a>
                    </li>
                </ul>
            </nav>

            <!-- Lựa chọn số lượng khách hàng mỗi trang -->
            <form method="get" class="d-flex my-3 align-items-center" style="max-width: 120px;">
                <select id="limit" name="limit" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="5" <?php if ($limit == 5) echo 'selected'; ?>>5</option>
                    <option value="10" <?php if ($limit == 10) echo 'selected'; ?>>10</option>
                    <option value="15" <?php if ($limit == 15) echo 'selected'; ?>>15</option>
                </select>
            </form>
    </div>
    <!-- Footer -->
    <?php include '../../includes/footer.php'; ?>
</body>

</html>