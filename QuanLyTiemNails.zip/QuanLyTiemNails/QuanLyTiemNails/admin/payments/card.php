<?php
require_once '../../config/database.php';
spl_autoload_register(function ($className) {
    require_once "../../app/model/$className.php";
});

// Lấy tổng tiền từ POST
$total = isset($_POST['total']) ? $_POST['total'] : 0;
?>

<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thanh toán thẻ</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background-color: #f8f9fa;
        }

        .payment-container {
            max-width: 500px;
            margin: 50px auto;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        .form-label {
            font-weight: bold;
        }

        .btn-primary {
            background-color: #00564e;
            border-color: #00564e;
        }

        .btn-primary:hover {
            background-color: #00443c;
        }

        .total-amount {
            font-size: 1.5rem;
            color: #00564e;
            text-align: center;
            margin-bottom: 20px;
        }

        .footer-text {
            text-align: center;
            margin-top: 20px;
            font-size: 0.9rem;
            color: #6c757d;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="payment-container">
            <h2 class="text-center">Thanh toán thẻ</h2>
            
            <!-- Hiển thị tổng tiền -->
            <div class="total-amount">
                <p>Tổng Tiền: <?php echo number_format($total, 2); ?> VND</p>
            </div>

            <form action="search.php" method="get">
                <div class="mb-3">
                    <label for="cardNumber" class="form-label">Số thẻ</label>
                    <input type="text" class="form-control" id="cardNumber" name="cardNumber" placeholder="1234 5678 9101 1121" required>
                </div>
                <div class="mb-3">
                    <label for="cardHolder" class="form-label">Tên chủ thẻ</label>
                    <input type="text" class="form-control" id="cardHolder" name="cardHolder" placeholder="Nguyen Van A" required>
                </div>
                <div class="mb-3">
                    <label for="expiryDate" class="form-label">Ngày hết hạn</label>
                    <div class="row">
                        <div class="col">
                            <input type="text" class="form-control" id="expiryMonth" name="expiryMonth" placeholder="MM" required>
                        </div>
                        <div class="col">
                            <input type="text" class="form-control" id="expiryYear" name="expiryYear" placeholder="YY" required>
                        </div>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="cvv" class="form-label">CVV</label>
                    <input type="password" class="form-control" id="cvv" name="cvv" placeholder="123" required>
                </div>
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary">Xác nhận thanh toán</button>
                    <a href="../payents/index.php" class="btn btn-secondary">Quay lại</a>
                </div>
            </form>

            <div class="footer-text">
                <p>Bảo mật thông tin thẻ của bạn. Không chia sẻ mã CVV với bất kỳ ai.</p>
            </div>

            <?php
            ?>
        </div>
    </div>
</body>

</html>
