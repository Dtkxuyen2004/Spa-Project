<?php
require_once '../../config/database.php';
spl_autoload_register(function ($className) {
    require_once "../../app/model/$className.php";
});

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $customer_id = $_POST['customer_id'];
    $service_ids = $_POST['service_ids'] ?? [];
    $staff_ids = $_POST['staff_ids'] ?? [];
    $method_payment = $_POST['method_payment'];
    $total = $_POST['total'];

    if (empty($customer_id) || empty($service_ids) || empty($staff_ids) || empty($method_payment) || empty($total)) {
        die("Thiếu dữ liệu đầu vào.");
    }

    // Lấy tên khách hàng
    $customerModel = new Customer();
    $customer = $customerModel->find($customer_id);
    $customer_name = $customer['customer_name'];

    // Lấy tên dịch vụ
    $serviceModel = new Service();
    $service_names = [];
    foreach ($service_ids as $service_id) {
        $service = $serviceModel->findById($service_id);
        if ($service) { // Kiểm tra nếu $service không rỗng
            $service_names[] = $service['service_name'] . " (" . $service['price'] . " $" . ")";
        } else {
            error_log("Không tìm thấy dịch vụ với ID: $service_id");
        }
    }
    $service_names = implode(", ", $service_names);

    // Lấy tên nhân viên
    $staffModel = new Staff();
    $staff_names = [];
    foreach ($staff_ids as $staff_id) {
        $staff = $staffModel->find($staff_id);
        $staff_names[] = $staff['name'];
    }
    $staff_names = implode(", ", $staff_names);

    // Lưu thông tin thanh toán
    $paymentModel = new Payment();
    $payment_id = $paymentModel->create([
        'customer_id' => $customer_id,
        'customer_name' => $customer_name,
        'staff_ids' => json_encode($staff_ids),
        'staff_names' => $staff_names,
        'service_ids' => json_encode($service_ids),
        'service_names' => $service_names,
        'total' => $total,
        'method_payment' => $method_payment
    ]);
    header('Location: search.php');
    exit();



// Xử lý thanh toán ở đây (tạo giao dịch, lưu thông tin vào cơ sở dữ liệu, v.v.)


}
