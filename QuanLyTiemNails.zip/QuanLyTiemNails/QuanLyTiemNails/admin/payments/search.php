<?php
require_once '../../config/database.php';
spl_autoload_register(function ($className) {
    require_once "../../app/model/$className.php";
});
$loginUrl = 'http://localhost/QuanLyTiemNails/QuanLyTiemNails/index.php';
// Fetch từ bảng payments dựa trên từ khóa tìm kiếm
$keyword = isset($_GET['q']) ? trim($_GET['q']) : '';
$paymentModel = new Payment();

if ($keyword) {
    $payments = $paymentModel->searchPayments($keyword);
} else {
    $payments = $paymentModel->getAllPayments();
}
?>


<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Danh Sách Thanh Toán</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .search-bar {
            width: 100%;
            max-width: 600px;
            margin: 20px auto;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .search-bar input {
            flex: 1;
            padding: 10px;
            border-radius: 25px;
            border: 1px solid #ccc;
        }

        .search-bar button {
            padding: 10px 20px;
            border-radius: 25px;
            background-color: #0056b3;
            color: white;
            border: none;
            cursor: pointer;
        }

        .search-bar button:hover {
            background-color: #004494;
        }

        .table th {
            background-color: #0056b3;
            color: white;
        }

        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .btn-primary {
            background-color: #0056b3;
            border-color: #0056b3;
        }

        .btn-primary:hover {
            background-color: #004494;
            border-color: #004494;
        }

        h1 {
            color: #0056b3;
            margin-bottom: 20px;
        }

        body {
            background-color: #f8f9fa;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
        }

        main {
            flex: 1;
        }

        footer {
            background-color: #00564e;
            color: white;
            text-align: center;
            padding: 10px 0;
            flex-shrink: 0;
        }

        .navbar {
            background-color: #00564e;
        }

        .navbar-brand,
        .nav-link {
            color: white !important;
        }

        .back-button a:hover {
            margin-top: 20px;
            color: #ccc;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <?php include '../../includes/header.php'; ?>
    <main>
        <div class="container">
            <div class="back-button">
                <a href="./" class="btn btn-secondary">&larr; Quay Lại</a>
            </div>
            <h1 class="text-center mt-4">Danh Sách Thanh Toán</h1>

            <!-- Thanh Tìm Kiếm -->
            <form class="search-bar" method="GET" action="">
                <input type="text" name="q" placeholder="Tìm kiếm thanh toán..." value="<?php echo htmlspecialchars($keyword); ?>">
                <button type="submit">Tìm Kiếm</button>
            </form>

            <!-- Bảng Hiển Thị -->
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>Khách Hàng</th>
                            <th>Nhân Viên</th>
                            <th>Dịch Vụ</th>
                            <th>Tổng Tiền (VND)</th>
                            <th>Hình Thức</th>
                            <th>Ngày Tạo</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($payments)) : ?>
                            <?php foreach ($payments as $payment) : ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($payment['customer_name']); ?></td>
                                    <td><?php echo htmlspecialchars($payment['staff_names']); ?></td>
                                    <td><?php echo htmlspecialchars($payment['service_names']); ?></td>
                                    <td><?php echo number_format($payment['total'], 2); ?> VND</td>
                                    <td><?php echo ucfirst($payment['method_payment']); ?></td>
                                    <td><?php echo date('d/m/Y H:i:s', strtotime($payment['created_at'])); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="7" class="text-center">Không tìm thấy thanh toán nào!</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
    <!-- Footer -->
    <?php include '../../includes/footer.php'; ?>
</body>

</html>