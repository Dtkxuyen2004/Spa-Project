<?php
session_start();
require_once '../../config/database.php';
spl_autoload_register(function ($className) {
    require_once "../../app/model/$className.php";
});
$loginUrl = 'http://localhost/QuanLyTiemNails/QuanLyTiemNails/index.php';

// Fetch data for dropdowns
$customerModel = new Customer();
$serviceModel = new Service();
$staffModel = new Staff();

$customers = $customerModel->all();
$services = $serviceModel->all();
$staffs = $staffModel->all();
?>

<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thanh Toán</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .btn-primary {
            background-color: #0056b3;
            border-color: #0056b3;
        }

        .btn-primary:hover {
            background-color: #004494;
            border-color: #004494;
        }

        h1 {
            color: #0056b3;
            margin-bottom: 20px;
        }

        body {
            background-color: #f8f9fa;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
        }

        main {
            flex: 1;
        }

        footer {
            background-color: #00564e;
            color: white;
            text-align: center;
            padding: 10px 0;
            flex-shrink: 0;
        }

        .navbar {
            background-color: #00564e;
        }

        .navbar-brand,
        .nav-link {
            color: white !important;
        }

        .back-button a:hover {
            color: #ccc;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <?php include '../../includes/header.php'; ?>
    <main>
        <div class="container mt-5">
            <div class="back-button">
                <a href="../main/index.php" class="btn btn-secondary">&larr; Quay Lại</a>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="card p-4">
                        <div class="back-button">
                            <a href="./search.php" class="btn btn-primary">&larr; Tìm kiếm danh sách Thanh Toán</a>
                        </div>
                        <h1 class="text-center">Trang Thanh Toán</h1>
                        <form id="paymentForm" action="process_payment.php" method="post"  onsubmit="return changeActionBasedOnPaymentMethod()">
                            <!-- Chọn Khách Hàng -->
                            <div class="mb-3">
                                <label for="customer" class="form-label">Khách Hàng</label>
                                <select id="customer" name="customer_id" class="form-select" required>

                                    <option value="" disabled selected>Chọn Khách Hàng</option>
                                    <?php foreach ($customers as $customer): ?>
                                        <option value="<?php echo $customer['id']; ?>">
                                            <?php echo $customer['customer_name']; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <!-- Chọn Dịch Vụ -->
                            <div class="mb-3">
                                <label for="services" class="form-label">Dịch Vụ</label>
                                <select id="services" name="service_ids[]" class="form-select" multiple required onchange="calculateTotal()">
                                    <?php foreach ($services as $service): ?>
                                        <option value="<?php echo $service['service_id']; ?>" data-price="<?php echo $service['price']; ?>">
                                            <?php echo $service['service_name'] . " - " . $service['price']; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <small class="form-text text-muted">Nhấn Ctrl + Click để chọn nhiều dịch vụ.</small>
                            </div>

                            <!-- Chọn Nhân Viên -->
                            <div class="mb-3">
                                <label for="staffs" class="form-label">Nhân Viên</label>
                                <select id="staffs" name="staff_ids[]" class="form-select" multiple required>
                                    <?php foreach ($staffs as $staff): ?>
                                        <option value="<?php echo $staff['id']; ?>">
                                            <?php echo $staff['name']; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <small class="form-text text-muted">Nhấn Ctrl + Click để chọn nhiều nhân viên.</small>
                            </div>

                            <!-- Tổng Tiền -->
                            <div class="mb-3">
                                <label for="total" class="form-label">Tổng Tiền</label>
                                <input type="number" id="total" name="total" class="form-control" readonly>
                            </div>

                            <!-- Hình Thức Thanh Toán -->
                        

                            <div class="mb-3">
                                <label for="method_payment" class="form-label">Hình Thức Thanh Toán</label>
                                <select id="method_payment" name="method_payment" class="form-select" required>
                                    <option value="cash">Tiền Mặt</option>
                                    <option value="card">Thẻ</option>
                                    <option value="online">Trực Tuyến</option>
                                </select>
                          </div>

                            <button type="submit" class="btn btn-primary w-100">Thanh Toán</button>
                            <!-- onclick="this.disabled = true; this.innerHTML='Đang xử lý...';" -->
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <!-- Footer -->
    <?php include '../../includes/footer.php'; ?>
    <script>
        function calculateTotal() {
            const services = document.querySelectorAll('#services option:checked');
            let total = 0;
            services.forEach(service => {
                total += parseFloat(service.getAttribute('data-price'));
            });
            document.getElementById('total').value = total.toFixed(2);
        }
        function changeActionBasedOnPaymentMethod() {
            const paymentMethod = document.getElementById('method_payment').value;
            const form = document.getElementById('paymentForm');

            // Kiểm tra nếu phương thức thanh toán là 'card'
            if (paymentMethod === 'card') {
                form.action = 'card.php';  // Đổi action của form tới card.php
            } else {
                form.action = 'process_payment.php';  // Nếu không phải thẻ, vẫn sử dụng process_payment.php
            }

            return true;  // Cho phép form được gửi đi
        }
    </script>
    </script>
    
</body>

</html>