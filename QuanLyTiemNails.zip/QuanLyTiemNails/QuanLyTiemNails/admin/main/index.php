<?php
$loginUrl = 'http://localhost/QuanLyTiemNails/QuanLyTiemNails/index.php';
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: $loginUrl");
    exit();
}
?>

<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trang Chính</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Đảm bảo Footer luôn ở cuối trang */
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
        }

        main {
            flex: 1;
        }

        footer {
            background-color: #00564e;
            color: white;
            padding: 10px 0;
            text-align: center;
        }

        .navbar {
            background-color: #00564e;
        }

        .navbar-brand,
        .nav-link {
            color: white !important;
        }

        /* Card Styling */
        .card {
            display: flex;
            flex-direction: row;
            align-items: center;
            padding: 15px;
            transition: transform 0.3s ease-in-out;
        }

        .card:hover {
            transform: scale(1.05);
        }

        .card img {
            width: 30%;
            height: 30%;
            object-fit: cover;
            margin-right: 20px;
        }

        .card-title {
            margin: 0;
            text-align: left;
            color: #00564e;
            font-size: 1.25rem;
        }

        .card-link {
            text-decoration: none;
            color: inherit;
        }
        .custom-card {
      
        height: 140px;    /* Giới hạn chiều cao */
    }
    .custom-card img {
        height: 120px;    /* Chiều cao ảnh */
        object-fit: cover; /* Cắt ảnh nếu vượt quá kích thước */
    }
    </style>
</head>

<body>
    <!-- Thanh Điều Hướng -->
    <?php include '../../includes/header.php'; ?>

    <!-- Nội Dung Chính -->
    <main class="container mt-4">
        <div class="row g-4">
            <!-- Dịch Vụ -->
            <div class="col-md-6">
                <a href="../services/index.php" class="card-link">
                    <div class="card shadow">
                        <img src="../../public/images/dichvu.jpg" alt="Category">
                        <h5 class="card-title">Dịch Vụ</h5>
                    </div>
                </a>
            </div>
            <!-- Nhân Viên -->
            <div class="col-md-6">
                <a href="../staffs/index.php" class="card-link">
                    <div class="card shadow">
                        <img src="../../public/images/nhanvien.png" alt="Staff">
                        <h5 class="card-title">Nhân Viên</h5>
                    </div>
                </a>
            </div>
            <!-- Khách Hàng -->
            <div class="col-md-6">
                <a href="../customers/index.php" class="card-link">
                    <div class="card shadow">
                        <img src="../../public/images/khachhang.jpg" alt="Customer">
                        <h5 class="card-title">Khách Hàng</h5>
                    </div>
                </a>
            </div>
            <!-- Thanh Toán -->
            <div class="col-md-6">
                <a href="../payments/index.php" class="card-link">
                    <div class="card shadow">
                        <img src="../../public/images/thanhtoan2.jpg" alt="Payment">
                        <h5 class="card-title">Thanh Toán</h5>
                    </div>
                </a>
            </div>
            <!-- Đánh giágiá -->
           <!-- Đánh giá -->
<div class="col-md-6">
    <a href="../danhgia/index.php" class="card-link">
        <div class="card shadow custom-card">
            <img src="../../public/images/dgia.jpg" alt="danhgia" class="img-fluid">
            <h5 class="card-title">Đánh giá</h5>
        </div>
    </a>
</div>

        </div>
    </main>

    <!-- Footer -->
    <?php include '../../includes/footer.php'; ?>
</body>

</html>