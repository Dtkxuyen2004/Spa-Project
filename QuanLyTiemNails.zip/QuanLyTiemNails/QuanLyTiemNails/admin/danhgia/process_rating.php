<?php
$loginUrl = 'http://localhost/QuanLyTiemNails/QuanLyTiemNails/index.php';
session_start();

require_once '../../config/database.php';
spl_autoload_register(function ($className) {
    require_once "../../app/model/$className.php";
});

// Kiểm tra xem form đã được gửi hay chưa
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Lấy dữ liệu từ form
    $customerId = $_POST['customer_id'];
    $serviceRating = isset($_POST['service_rating']) ? $_POST['service_rating'] : '';
    $comments = $_POST['comments'];

    // Kiểm tra dữ liệu đã đầy đủ chưa
    if (empty($customerId) || empty($serviceRating) || empty($comments)) {
        echo json_encode(['error' => 'Vui lòng điền đầy đủ thông tin']);
        exit();
    }

    // Xử lý lưu dữ liệu vào cơ sở dữ liệu
    try {
        $ratingModel = new CustomerRating();
        $ratingModel->addRating($customerId, $serviceRating, $comments);

        // Chuyển hướng sau khi gửi thành công
        header("Location: raitings_list.php");
        exit();
    } catch (Exception $e) {
        echo json_encode(['error' => 'Đã có lỗi xảy ra. Vui lòng thử lại sau.']);
        exit();
    }
}
?>
