<?php
require_once '../../config/database.php';
spl_autoload_register(function ($className) {
    require_once "../../app/model/$className.php";
});

$ratingModel = new CustomerRating();
$ratings = $ratingModel->getAllRatings(); // Hàm lấy tất cả đánh giá từ cơ sở dữ liệu

?>
<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Danh Sách Đánh Giá</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background-color: #f8f9fa;
        }

        .rating-container {
            max-width: 800px;
            margin: 50px auto;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 30px;
        }

        .form-label {
            font-weight: bold;
        }

        .btn-primary {
            background-color: #00564e;
            border-color: #00564e;
        }

        .btn-primary:hover {
            background-color: #00443c;
        }

        .footer-text {
            text-align: center;
            margin-top: 20px;
            font-size: 0.9rem;
            color: #6c757d;
        }

        .star-rating {
            font-size: 1.5rem;
            color: #f39c12;
        }

        .rating-item {
            margin-bottom: 20px;
        }

        .rating-item h5 {
            margin-bottom: 5px;
        }

        .rating-item p {
            margin: 0;
            font-size: 1rem;
        }

        .rating-item .stars {
            color: #f39c12;
        }

        .rating-item .comment {
            font-style: italic;
            color: #6c757d;
        }

        /* Button to go back to index page */
        .back-btn {
            margin-bottom: 20px;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="rating-container">
            <h2 class="text-center">Danh Sách Đánh Giá Dịch Vụ</h2>

            <!-- Button to go back to index.php -->
            <div class="back-btn text-center">
                <a href="index.php" class="btn btn-secondary">Quay lại Trang Chủ</a>
            </div>

            <?php if (count($ratings) > 0): ?>
                <?php foreach ($ratings as $rating): ?>
                    <div class="rating-item">
                        <h5><?php echo $rating['customer_name']; ?> <span class="stars">
                            <?php for ($i = 0; $i < $rating['service_rating']; $i++): ?>
                                ★
                            <?php endfor; ?>
                        </span></h5>
                        <p class="comment">"<?php echo $rating['comments']; ?>"</p>
                        <p><small>Đánh giá vào lúc: <?php echo date("d/m/Y H:i:s", strtotime($rating['created_at'])); ?></small></p>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Chưa có đánh giá nào.</p>
            <?php endif; ?>
            
        </div>
    </div>
</body>

</html>
