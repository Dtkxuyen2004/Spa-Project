<?php
$loginUrl = 'http://localhost/QuanLyTiemNails/QuanLyTiemNails/index.php';
session_start();

// Kiểm tra người dùng đã đăng nhập chưa
if (!isset($_SESSION['user'])) {
    header("Location: $loginUrl");
    exit();
}

require_once '../../config/database.php';
spl_autoload_register(function ($className) {
    require_once "../../app/model/$className.php";
});

// Lấy danh sách khách hàng từ cơ sở dữ liệu
$customerModel = new Customer();
$customers = $customerModel->all();  // Giả sử bạn đã có phương thức `all()` để lấy tất cả khách hàng
?>

<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đánh Giá Dịch Vụ</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background-color: #f8f9fa;
        }

        .rating-container {
            max-width: 600px;
            margin: 50px auto;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 30px;
        }

        .form-label {
            font-weight: bold;
        }

        .btn-primary {
            background-color: #00564e;
            border-color: #00564e;
        }

        .btn-primary:hover {
            background-color: #00443c;
        }

        .footer-text {
            text-align: center;
            margin-top: 20px;
            font-size: 0.9rem;
            color: #6c757d;
        }

        .star-rating {
    display: flex;
    justify-content: center;
}

.star-label {
    font-size: 30px;
    color: #ddd; /* Màu sao mặc định (xám) */
    cursor: pointer;
    transition: color 0.3s ease; /* Hiệu ứng màu mượt mà */
}

.star-label:hover,
.star-rating input:checked ~ .star-label {
    color: gold; /* Màu vàng khi di chuột qua hoặc sao đã được chọn */
}

input[type="radio"] {
    display: none; /* Ẩn các input radio, chỉ hiển thị các label sao */
}

    </style>
</head>

<body>
    <div class="container">
        <div class="rating-container">
        <div class="back-button">
                <a href="../main/index.php" class="btn btn-secondary">&larr; Quay Lại</a>
            </div>
            <h2 class="text-center">Đánh Giá Dịch Vụ</h2>

            <form action="process_rating.php" method="post">
    <!-- Chọn Khách Hàng -->
    <div class="mb-3">
        <label for="customer" class="form-label">Khách Hàng</label>
        <select id="customer" name="customer_id" class="form-select" required>
            <option value="" disabled selected>Chọn Khách Hàng</option>
            <?php foreach ($customers as $customer): ?>
                <option value="<?php echo $customer['id']; ?>">
                    <?php echo $customer['customer_name']; ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>

    <!-- Đánh Giá Dịch Vụ -->
    <div class="mb-3">
    <label for="service_rating" class="form-label">Đánh Giá Dịch Vụ</label>
    <div class="star-rating">
        <input type="radio" name="service_rating" value="5" id="star5" class="rating-input">
        <label for="star5" class="star-label">&#9733;</label> <!-- Sử dụng ký tự sao Unicode -->
        
        <input type="radio" name="service_rating" value="4" id="star4" class="rating-input">
        <label for="star4" class="star-label">&#9733;</label>
        
        <input type="radio" name="service_rating" value="3" id="star3" class="rating-input">
        <label for="star3" class="star-label">&#9733;</label>
        
        <input type="radio" name="service_rating" value="2" id="star2" class="rating-input">
        <label for="star2" class="star-label">&#9733;</label>
        
        <input type="radio" name="service_rating" value="1" id="star1" class="rating-input">
        <label for="star1" class="star-label">&#9733;</label>
    </div>
</div>

    
    
        
    

    <!-- Nhận Xét -->
    <div class="mb-3">
        <label for="comments" class="form-label">Nhận Xét</label>
        <textarea class="form-control" id="comments" name="comments" rows="4" placeholder="Chia sẻ cảm nhận của bạn về dịch vụ..." required></textarea>
    </div>

    <div class="d-grid gap-2">
        <button type="submit" class="btn btn-primary">Gửi Đánh Giá</button>
    </div>
</form>


              

            <div class="footer-text">
                <p>Cảm ơn bạn đã chia sẻ đánh giá về dịch vụ của chúng tôi!</p>
            </div>
        </div>
    </div>
</body>

<script>
  document.addEventListener('DOMContentLoaded', function () {
    const stars = document.querySelectorAll('.star-label');
    const ratingInputs = document.querySelectorAll('.rating-input');

    // Đảm bảo sao đã chọn được hiển thị đúng khi trang tải lại
    const selectedRating = <?php echo $selectedRating ? $selectedRating : 'null'; ?>;
    if (selectedRating) {
        updateSelectedStar(selectedRating);
    }

    stars.forEach((star, index) => {
        star.addEventListener('mouseover', function () {
            highlightStars(index + 1);
        });

        star.addEventListener('mouseout', function () {
            const checkedStar = document.querySelector('.rating-input:checked');
            if (checkedStar) {
                highlightStars(parseInt(checkedStar.value));
            } else {
                resetStars();
            }
        });

        star.addEventListener('click', function () {
            updateSelectedStar(index + 1);
        });
    });

    function resetStars() {
        stars.forEach(star => {
            star.style.color = '#ddd';
        });
    }

    function highlightStars(count) {
        for (let i = 0; i < count; i++) {
            stars[i].style.color = 'gold';
        }
    }

    function updateSelectedStar(count) {
        resetStars();
        highlightStars(count);

        // Cập nhật trạng thái cho các input radio
        ratingInputs.forEach(input => {
            if (parseInt(input.value) <= count) {
                input.checked = true;
            } else {
                input.checked = false;
            }
        });
    }
});


</script>


</html>
