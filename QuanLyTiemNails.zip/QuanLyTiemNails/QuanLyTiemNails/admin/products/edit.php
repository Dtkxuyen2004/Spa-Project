<?php
require_once '../../config/database.php';
spl_autoload_register(function ($className) {
    require_once "../../app/models/$className.php";
});

$serviceModel = new Product();
$categoryModel = new Category();

if (!empty($_GET['id'])) {
    $serviceId = $_GET['id'];
    $service = $serviceModel->find($serviceId);
    $categories = $categoryModel->all();
    $serviceCategories = $serviceModel->getCategories($serviceId);
}

if (!empty($_POST['name']) && !empty($_POST['price']) && !empty($_POST['description']) && !empty($_POST['image'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $price = $_POST['price'];
    $description = $_POST['description'];
    $image = $_POST['image'];
    $category_ids = $_POST['category_id'];

    if ($serviceModel->update($id, $name, $price, $description, $image, $category_ids)) {
        header('Location: index.php?message=update  thành công!');
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<style>
    textarea {
        resize: vertical;
        max-height: 300px;
        overflow-y: auto;
    }
</style>

<body>
    <div class="container">
        <h1>Edit Product</h1>
        <form action="edit.php?id=<?php echo $service['id']; ?>" method="post">
            <input type="hidden" name="id" value="<?php echo $service['id']; ?>">
            <div class="mb-3">
                <label for="name" class="form-label">Name</label>
                <input type="text" class="form-control" id="name" name="name" value="<?php echo $service['name']; ?>">
            </div>
            <div class="mb-3">
                <label for="price" class="form-label">Price</label>
                <input type="text" class="form-control" id="price" name="price" value="<?php echo $service['price']; ?>">
            </div>
            <div class="mb-3">
                <label for="description" class="form-label">Description</label>
                <textarea class="form-control" id="description" name="description" rows="4" required><?php echo htmlspecialchars($service['description']); ?></textarea>
            </div>
            <div class="mb-3">
                <label for="image" class="form-label">Image</label>
                <input type="text" class="form-control" id="image" name="image" value="<?php echo $service['image']; ?>">
            </div>
            <div class="mb-3">
                <label for="categories" class="form-label">Categories</label>
                <select class="form-select" multiple name="category_id[]">
                    <?php foreach ($categories as $category) : ?>
                        <option value="<?php echo $category['id']; ?>" <?php echo in_array($category['id'], $serviceCategories) ? 'selected' : ''; ?>>
                            <?php echo $category['name']; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
</body>

</html>