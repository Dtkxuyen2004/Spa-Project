<?php 
require_once '../../config/database.php';
spl_autoload_register(function ($className) {
    require_once "../../app/models/$className.php";
});

// Lấy sản phẩm cùng với danh mục
$serviceModel = new Product();
$services = $serviceModel->all();

if (isset($_POST['productId'])) {
    if ($serviceModel->deleteBin($_POST['productId']))
        echo "Xóa thành công";
}

$services = $serviceModel->all();
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Shop</title>
    <link rel="stylesheet" href="public/css/styles.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<div class="container">
<h1>
            Manage Products <a href="add.php" class="btn btn-outline-primary">Add</a>
            <a href="delete.php" class="btn btn-outline-primary">
    <i class="fa-solid fa-trash"></i> Delete
</a>



</a>
        </h1>
        <table class="table">
            <thead>
                <tr>
                    <th>TD</th>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Categories</th>
                    <th>Image</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($services as $service) :
                ?>
                    <tr>
                        <td><?php echo $service['id'] ?></td>
                        <td><?php echo $service['name'] ?></td>
                        <td><?php echo $service['price'] ?></td>
                        <td>
                            <?php

                            echo (!empty($service['categories_name'])) ? implode(array_map(function ($e) {
                                return "<span class='badge text-bg-warning'>$e</span>";
                            }, explode(',', $service['categories_name']))) : '';

                            ?>
                        </td>
                        <td><img src="../../public/images/<?php echo $service['image'] ?>" width="50"></td>
                        <td>
                        <a href="edit.php?id=<?php echo $service['id'] ?>" class="btn btn-outline-primary">Edit</a>
                        <form action="index.php" method="post" onsubmit="return confirm('Xóa không?')">
                                <input type="hidden" name="productId" value="<?php echo $service['id'] ?>">
                                <button type="submit" class="btn btn-outline-danger">Delete</button>
                            </form>
                    </tr>
                <?php
                endforeach;
                ?>

            </tbody>
        </table>
    </div>
</body>

</html>
