<?php
require_once 'config/database.php';  // Kết nối cơ sở dữ liệu
spl_autoload_register(function ($className) {
    require_once "app/model/$className.php";  // Tự động tải các lớp trong thư mục app/model
});

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST['email']);
    $newPassword = trim($_POST['new_password']); // Lấy mật khẩu mới

    $userModel = new User();

    // Kiểm tra nếu email tồn tại trong hệ thống
    if ($userModel->findByEmail($email)) {
        // Mã hóa mật khẩu mới
        $newPasswordHashed = password_hash($newPassword, PASSWORD_DEFAULT);

        // Cập nhật mật khẩu trong cơ sở dữ liệu
        if ($userModel->updatePassword($email, $newPasswordHashed)) {
            $message = "Mật khẩu đã được cập nhật thành công.";
        } else {
            $message = "Đã có lỗi xảy ra, không thể cập nhật mật khẩu.";
        }
    } else {
        $message = "Không tìm thấy email này trong hệ thống.";
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đặt lại Mật khẩu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow">
                <div class="card-header text-center">
                    <h4>Đặt lại Mật khẩu</h4>
                </div>
                <div class="card-body">
                    <?php if ($message): ?>
                        <div class="alert alert-info"><?php echo htmlspecialchars($message); ?></div>
                    <?php endif; ?>
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" name="email" id="email" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="new_password" class="form-label">Mật khẩu mới</label>
                            <input type="password" name="new_password" id="new_password" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Cập nhật mật khẩu</button>
                    </form>
                    <div class="text-center mt-3">
                        <a href="index.php" class="text-decoration-none" style="color: #00564e;">Quay lại trang đăng nhập</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
