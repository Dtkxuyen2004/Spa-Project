-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 10, 2024 at 03:36 AM
-- Server version: 8.3.0
-- PHP Version: 8.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tiemnail`
--

-- --------------------------------------------------------

-- Tạo cơ sở dữ liệu
CREATE DATABASE IF NOT EXISTS `nails_spa`;
USE `nails_spa`;

-- Table structure for table `users`
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_name` VARCHAR(50) NOT NULL,
    `password` TEXT NOT NULL,
    `full_name` VARCHAR(100) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Dumping data for table `users`
INSERT INTO `users` (`user_name`, `password`, `full_name`) VALUES
('admin', 'admin', 'Administrator');


-- Table structure for table `danhmuc`
DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `discription` text COLLATE utf8mb4_unicode_ci,
  `create_date` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `danhmuc`
--

INSERT INTO `categories` (`id`, `category_name`, `discription`) VALUES
(1, 'CHĂM SÓC DA MẶT', 'sẽ bao gồm : Massge mặt , nặn mụn , tẩy da chết mặt , cạo lông mặt. '),
(2, 'LÀM MÓNG TAY CHÂN', 'Sẽ bao gồm : sơn màu , tạo kiểu đính đá , đắp móng , dưỡng móng , cắt da chết  '),
(3, 'GỘI ĐẦU ', 'bao gồm : gội đầu dưỡng dinh , gội đầu massge '),
(4, 'TRIỆT LÔNG', 'sẽ gồm : Triệt lông cánh tay , triệt lông chân , triệt lông toàn thân .. ');

-- --------------------------------------------------------

--
-- Table structure for table `danhmuc_dichvu`
--

DROP TABLE IF EXISTS `category_service`;
CREATE TABLE IF NOT EXISTS `category_service`(
  `service_id` int NOT NULL,
  `category_id` int NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `danhmuc_dichvu`
--

INSERT INTO `category_service` (`category_id`, `service_id`) VALUES
(1, 1),
(1, 2),
(1, 3),
(2, 4),
(2, 5),
(2, 6),
(2, 7),
(3, 8),
(3, 9),
(4, 10),
(4, 11),
(4, 12);

-- --------------------------------------------------------

--
-- Table structure for table `dichvu`
--

DROP TABLE IF EXISTS `services`;
CREATE TABLE IF NOT EXISTS `services` (
  `id` int NOT NULL AUTO_INCREMENT,
  `service_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `service_duration` int NOT NULL,
  `create_date` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `dichvu`
--

INSERT INTO `services` (`id`, `service_name`, `price`, `service_duration`) VALUES
(1, 'Massge mặt ', 39.00, 10),
(2, 'Tẩy da chết mặt', 59.00, 20),
(3, 'Nặn mụn ', 89.00, 0),
(4, 'Sơn móng', 159.00, 0),
(5, 'Tạo kiểu đính đá', 49.00, 0),
(6, 'Đắp móng', 89.00, 0),
(7, 'Cắt da chết', 69.00, 0),
(8, 'Gội đầu dưỡng sinh ', 129.00, 0),
(9, 'Gội đầu massge', 99.00, 0),
(10, 'Triệt lông cánh tay', 299.00, 0),
(11, 'Triệt lông chân', 309.00, 0),
(12, 'Triệt lông toàn thân', 999.00, 0);

-- --------------------------------------------------------

--
-- Table structure for table `giaodich`
--

DROP TABLE IF EXISTS `payments`;
CREATE TABLE IF NOT EXISTS `payments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `total` decimal(10,2) NOT NULL,
  `method_payment` enum('cash','card','online') COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` varchar(100),
  `create_date` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `giaodich`
--

INSERT INTO `giaodich` (`id`, `total`, `method_payment`, `create_date`) VALUES
(1, 10000, 'cash', '2024-12-10 10:35:11'),
(2, 9000, 'card', '2024-12-10 10:36:00');

-- --------------------------------------------------------

--
-- Table structure for table `khachhang`
--

DROP TABLE IF EXISTS `customers`;
CREATE TABLE IF NOT EXISTS `customers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `create_date` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phone` (`phone`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `khachhang`
--

INSERT INTO `customers` (`id`, `customer_name`, `phone`, `email`, `address`, `create_date`) VALUES
(1, 'Nguyễn Lê Kim Hoàng ', '033445578', 'kimhoang@gmail.com', '27 Chương Dương , Linh Chiểu , Thủ Đức , Hồ Chí Minh', '2024-12-10 10:28:12'),
(2, 'Trần Thị Hoàng Yến ', '035544127', 'hoangyen@gmail.com', '8 Nguyễn Huy Tưởng , Phường 6 , Quận Bình Thạnh , Thành Phố Hồ Chí Minh', '2024-12-10 10:28:12'),
(3, 'Nguyễn Thị Yến Nhi', '0334455781', 'mai@gmail.com', '45 Võ Văn Ngân , Linh Chiểu , Thủ Đức , Thành Phố Hồ Chí Minh', '2024-12-10 10:29:31');

-- --------------------------------------------------------

--
-- Table structure for table `lichhen`
--

DROP TABLE IF EXISTS `lichhen`;
CREATE TABLE IF NOT EXISTS `lichhen` (
  `id` int NOT NULL AUTO_INCREMENT,
  `khach_hang_id` int NOT NULL,
  `nhan_vien_id` int NOT NULL,
  `dich_vu_id` int NOT NULL,
  `thoi_gian` datetime NOT NULL,
  `trang_thai` enum('pending','completed','canceled') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `ghi_chu` text COLLATE utf8mb4_unicode_ci,
  `ngay_tao` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `khach_hang_id` (`khach_hang_id`),
  KEY `nhan_vien_id` (`nhan_vien_id`),
  KEY `dich_vu_id` (`dich_vu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lichhen`
--

INSERT INTO `lichhen` (`id`, `khach_hang_id`, `nhan_vien_id`, `dich_vu_id`, `thoi_gian`, `trang_thai`, `ghi_chu`, `ngay_tao`) VALUES
(1, 1, 2, 4, '2024-12-10 03:33:10', 'pending', NULL, '2024-12-10 10:33:43');

-- --------------------------------------------------------

--
-- Table structure for table `nhanvien`
--

DROP TABLE IF EXISTS `staffs`;
CREATE TABLE IF NOT EXISTS `staffs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `staff_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `staff_phone` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `create_date` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `staff_phone` (`staff_phone`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nhanvien`
--

INSERT INTO `staffs` (`id`, `staff_name`, `staff_phone`, `email`, `create_date`) VALUES
(1, 'Kim Xuyến ', '0334455781', 'xuyen@gmail.com',  '2024-12-10 10:32:31'),
(2, 'Như Quỳnh ', '0334455767', 'quynh@gmail.com', '2024-12-10 10:32:56');
COMMIT;


CREATE TABLE IF NOT EXISTS `payment_staff` (
  `payment_id` int NOT NULL,
  `staff_id` int NOT NULL,
  PRIMARY KEY (`payment_id`, `staff_id`),
  FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`staff_id`) REFERENCES `staffs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `payment_service` (
  `payment_id` int NOT NULL,
  `service_id` int NOT NULL,
  PRIMARY KEY (`payment_id`, `service_id`),
  FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



