<?php
session_start();
require_once '../config/database.php';
spl_autoload_register(callback: function ($className) {
	require_once "../app/model/$className.php";
});

// Khởi tạo biến thông báo lỗi hoặc thành công
$message = "";

// // Kiểm tra người dùng đã đăng nhập chưa
// if (!isset($_SESSION['user'])) {
//     header("Location: index.php"); // Nếu chưa đăng nhập, chuyển hướng về trang đăng nhập
//     exit();
// }

// Lấy thông tin người dùng từ session
$userId = $_SESSION['userId'];
$userName = $_SESSION['user'];
$userEmail = $_SESSION['email']; // Thêm email hoặc các thông tin khác nếu cần
$userPhone = isset($_SESSION['phone']) ? $_SESSION['phone'] : 'Chưa có số điện thoại'; // Ví dụ có thêm số điện thoại

// Kiểm tra nếu có lỗi hoặc thông báo
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $newEmail = $_POST['userEmail'];
    $newPhone = $_POST['userPhone'];

    // Giả sử bạn có một class UserModel để xử lý thông tin người dùng
    $userModel = new User();
    $userModel->updateUserInfo($_SESSION['userId'], $newEmail, $newPhone);

    // Cập nhật lại session nếu thành công
    $_SESSION['email'] = $newEmail;
    $_SESSION['phone'] = $newPhone;
    $userEmail = $newEmail;
    $userPhone = $newPhone;

    $message = "Thông tin đã được cập nhật thành công!";
}
?>

<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thông Tin Cá Nhân</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>
<div class="back-button">
                <a href="../admin/main/index.php" class="btn btn-secondary">&larr; Quay Lại</a>
            </div>
    <div class="container mt-5">
        <h2>Thông Tin Cá Nhân</h2>

        <!-- Hiển thị thông báo nếu có -->
        <?php if ($message != ""): ?>
            <div class="alert alert-success" role="alert">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Xin chào, <?php echo htmlspecialchars($userName); ?>!</h5>
                <p class="card-text"><strong>Email:</strong> <?php echo htmlspecialchars($userEmail); ?></p>
                <p class="card-text"><strong>Số điện thoại:</strong> <?php echo htmlspecialchars($userPhone); ?></p>
                
                <form action="thongtincanhan.php" method="POST">
                    <div class="mb-3">
                        <label for="new_email" class="form-label">Thay đổi email</label>
                        <input type="email" id="userEmail" name="userEmail" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label for="new_phone" class="form-label">Thay đổi số điện thoại</label>
                        <input type="text" id="userPhone" name="userPhone" class="form-control">
                    </div>
                    <button type="submit" class="btn btn-primary">Cập nhật thông tin</button>
                </form>

                <a href="http://localhost/QuanLyTiemNails/QuanLyTiemNails/index.php" class="btn btn-danger mt-3">Đăng xuất</a>
            </div>
        </div>
    </div>
</body>

</html>
