<?php
require_once '../config/database.php';
spl_autoload_register(callback: function ($className) {
	require_once "../app/model/$className.php";
});

// Lấy sản phẩm cùng với danh mục
// $productModel = new Product();
// $products = $productModel->all();

// if (isset($_POST['productId'])) {
//     if ($productModel->deleteBin($_POST['productId']))
//         echo "Xóa thành công";
// }

// $products = $productModel->all();
?>

<!DOCTYPE html>
<html>

<head>
	<title>Trang đăng nhập</title>
	<meta charset="utf-8">
</head>

<body>
	<form method="POST" action="login.php">
		<fieldset align="center">
			<legend>Đăng nhập</legend>
			<table align="center">
				<tr>
					<td>Username</td>
					<td><input type="text" name="username" size="30"></td>
				</tr>
				<tr>
					<td>Password</td>
					<td><input type="password" name="	" size="30"></td>
				</tr>
				<tr>
					<td colspan="2" align="center"> <input type="submit" name="btn_submit" value="Đăng nhập"></td>
				</tr>
			</table>
		</fieldset>
	</form>
</body>

</html>