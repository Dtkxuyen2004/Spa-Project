<?php
session_start();
require_once 'config/database.php';
spl_autoload_register(callback: function ($className) {
	require_once "app/model/$className.php";
});

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['token'];
    $newPassword = $_POST['password'];

    // Kết nối cơ sở dữ liệu
    $db = (new Database())->connect();

    // Kiểm tra token hợp lệ
    $stmt = $db->prepare("SELECT id FROM users WHERE reset_token = :token AND reset_expires_at > NOW()");
    $stmt->execute(['token' => $token]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

        // Cập nhật mật khẩu và xóa token
        $stmt = $db->prepare("UPDATE users SET password = :password, reset_token = NULL, reset_expires_at = NULL WHERE id = :id");
        $stmt->execute([
            'password' => $hashedPassword,
            'id' => $user['id']
        ]);

        echo "Mật khẩu đã được đặt lại thành công.";
    } else {
        echo "Liên kết đặt lại mật khẩu không hợp lệ hoặc đã hết hạn.";
    }
} elseif (isset($_GET['token'])) {
    $token = $_GET['token'];
} else {
    echo "Không tìm thấy token.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đặt Lại Mật Khẩu</title>
</head>
<body>
    <h2>Đặt Lại Mật Khẩu</h2>
    <form action="reset_password.php" method="POST">
        <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
        <label for="password">Mật khẩu mới:</label>
        <input type="password" id="password" name="password" required>
        <button type="submit">Đặt Lại</button>
    </form>
</body>
</html>
